import { Log, Wings } from 'wings'
import { camera } from '@kit.CameraKit';
import { Options } from './Options';

const TAG = 'PreviewAreaWings'

export class PreviewAreaWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public setFocus(captureSession: camera.CaptureSession, res: any): boolean {
    if (!Options.isSetFocus()) {
      return false;
    }
    let state = this.getAPObj('state');
    if(state.cameraPosition == 'BACK'){
      try {
        this.setAPObj('harcherOSFocusImageX', res.x - 30 < 0 ? 0 : res.x - 30);
        this.setAPObj('harcherOSFocusImageY', res.y - 30 < 0 ? 0 : res.y - 30);
        this.setAPObj('harcherOSShowFocusImage', true);
        this.getAPObj('mAction').setFocus(res.x - 30 < 0 ? 0 : res.x - 30, res.y - 30 < 0 ? 0 : res.y - 30, state.xComponentWidth, state.xComponentHeight);
        Log.showInfo(TAG, 'Camera setFocus start.');
        captureSession.setFocusPoint({ x: (res.x - 30 < 0 ? 0 : res.x - 30) / state.xComponentWidth, y: (res.y - 30 < 0 ? 0 : res.y - 30) / state.xComponentHeight })
        setTimeout(() => {
          this.setAPObj('harcherOSShowFocusImage', false);
        }, 3000)
      } catch (err) {
        Log.showError(TAG, 'Camera setFocus Error.' + JSON.stringify(err));
      }
    }
    return true;
  }

}