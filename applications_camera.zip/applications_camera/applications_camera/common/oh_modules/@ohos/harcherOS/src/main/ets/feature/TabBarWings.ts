import { Log, Wings } from 'wings'
import { promptAction } from '@kit.ArkUI';
import { batteryInfo } from '@kit.BasicServicesKit';
import { Options } from './Options';

const TAG = 'TabBarWings'

export class TabBarWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public setFlashMode(flashMode: number): boolean {
    if (!Options.isSupportFlash()) {
      return false;
    }
    try {
      if(this.getAPObj('harcherOSGlobalContext').getCaptureSession().isFlashModeSupported(flashMode)){
        try {
          this.getAPObj('harcherOSGlobalContext').getCaptureSession().setFlashMode(flashMode);
          AppStorage.setOrCreate('flashMode', flashMode);
          Log.showInfo(TAG, 'setFlashMode success');
          this.setAPObj('flashMode', flashMode);
          this.setAPObj('flashHeight', 0);
        } catch (error) {
          Log.showError(TAG, 'setFlashMode error: ' + error.code);
          promptAction.showToast({
            message: '设置闪光灯失败'
          })
        }
      }
    } catch (error) {
      Log.showError(TAG, 'isFlashModeSupported error: ' + error.code);
      promptAction.showToast({
        message: '获取闪光灯参数失败'
      })
    }
    return true;
  }

  public showFlashMenu(): boolean {
    if (!Options.isSupportFlash()) {
      return false;
    }
    Log.showError(TAG, 'batterySOC: ' + batteryInfo.batterySOC);
    if (batteryInfo.batterySOC <= 10) {
      promptAction.showToast({
        message: '低电量暂时无法使用闪光灯'
      })
      return false;
    }
    if(this.getAPObj('flashHeight') == 0) {
      this.setAPObj('flashHeight', 130);
    }else if(this.getAPObj('flashHeight') == 130){
      this.setAPObj('flashHeight', 0);
    }
    return true;
  }

}