import { Log, Wings } from 'wings'
import { window } from '@kit.ArkUI'
import { Options } from './Options'
const TAG = 'IndexWings'

export class IndexWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public setSystemBarEnable(winClass: window.Window, config: Array<"status" | "navigation">, statusBarContentColor: string) {
    if (!Options.isCanSetSystemBarEnable()) {
      return false;
    }
    winClass.setWindowLayoutFullScreen(true).then(() => {
      Log.showInfo(TAG, 'Camera setFullScreen finished.')
      winClass.setWindowSystemBarEnable(config).then(() => {
        Log.showInfo(TAG, 'Camera setSystemBarEnable finished.')
      })
    })
    winClass.setWindowSystemBarProperties({
      navigationBarColor: '#00000000', navigationBarContentColor: '#B3B3B3', statusBarContentColor: statusBarContentColor
    }).then(() => {
      Log.showInfo(TAG, 'Camera setSystemBarProperties.')
    })
  }

}