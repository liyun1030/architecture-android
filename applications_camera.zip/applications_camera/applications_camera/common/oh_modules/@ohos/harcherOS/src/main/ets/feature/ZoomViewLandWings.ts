import { Log, Wings } from 'wings'
import { window } from '@kit.ArkUI'
import { Options } from './Options'
const TAG = 'ZoomViewLandWings'

export class ZoomViewLandWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public takingVideoCanvas() {
    if (!Options.isTakingVideoCanvas()) {
      return false;
    }
    this.callAPFun('takingVideoCanvas')
  }

  public refreshCanvas() {
    if (!Options.isRefreshCanvas()) {
      return false;
    }
    this.callAPFun('refreshCanvas', this.getAPObj('refreshSwitchCanvas'))
  }

  public getZoomBtnCenterY(result): number | undefined {
    if (!Options.isGetZoomBtnCenterY()) {
      return undefined;
    }
    let min = this.callAPFun('getPadding') + this.getAPObj('mainDotRadius');
    if (result < min) {
      return min;
    }
    let max = this.getAPObj('notTakeVideoExtCanvasHeight') - this.callAPFun('getPadding') - this.getAPObj('mainDotRadius');
    if (result > max) {
      return max;
    }
  }

}