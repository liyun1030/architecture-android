import { Log, MemberHelper } from 'wings'

const IMPORT_TAG = 'HarcherOS_import'

export class HarcherOS extends MemberHelper {
  constructor(ins: ESObject) {
    super(ins)
  }

  public init(instanceName: string): HarcherOS {
    // 这里要在程序里写好import的值,这里需要提前找好对应关系,否则会出现问题
    let tag = Log.recordStart(IMPORT_TAG, instanceName)
    switch (instanceName) {
      case 'IndexLand':
        import('./IndexLandWings').then(res => {
          this.processer = new res.IndexLandWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'ControlLand':
        import('./ControlLandWings').then(res => {
          this.processer = new res.ControlLandWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'PreviewAreaLand':
        import('./PreviewAreaLandWings').then(res => {
          this.processer = new res.PreviewAreaLandWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'FootBarLand':
        import('./FootBarLandWings').then(res => {
          this.processer = new res.FootBarLandWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'TabBar':
        import('./TabBarWings').then(res => {
          this.processer = new res.TabBarWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'PreviewArea':
        import('./PreviewAreaWings').then(res => {
          this.processer = new res.PreviewAreaWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'Index':
        import('./IndexWings').then(res => {
          this.processer = new res.IndexWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'CameraService':
        import('./CameraServiceWings').then(res => {
          this.processer = new res.CameraServiceWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'ZoomViewLand':
        import('./ZoomViewLandWings').then(res => {
          this.processer = new res.ZoomViewLandWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'TabletSetResolution':
        import('./TabletSetResolutionWings').then(res => {
          this.processer = new res.TabletSetResolutionWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'SetResolution':
        import('./TabletSetResolutionWings').then(res => {
          this.processer = new res.TabletSetResolutionWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
      case 'TabletSettingItem':
        import('./TabletSettingItemWings').then(res => {
          this.processer = new res.TabletSettingItemWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
    }
    return this
  }
}

HarcherOS.isDebug = true
// 关闭所有特性
HarcherOS.closeAll = false