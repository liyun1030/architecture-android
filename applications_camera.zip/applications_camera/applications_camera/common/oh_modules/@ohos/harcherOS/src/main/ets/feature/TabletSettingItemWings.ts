import { Log, Wings } from 'wings'
import { Options } from './Options'
const TAG = 'TabletSettingItemWings'

export class TabletSettingItemWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public showSettingsMenu(index) {
    if (Options.isShowAllSettingsMenu()) {
      return true;
    }
    if (index == 2 || index == 4) {
      return false;
    }
    return true;
  }


}