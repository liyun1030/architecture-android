import { Log, Wings } from 'wings'
import { Options } from './Options';

const TAG = 'TabletSetResolutionWings'

export class TabletSetResolutionWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public setCustomDialogDetails(itemValue, context) {
    if (!Options.isShowSettings()) {
      return false;
    }
    let temp = itemValue?.radio;
    let customDialogDetails = this.getAPObj('customDialogDetails');
    customDialogDetails.childrenList = []
    for (let i = 0; i < temp.length; i++) {
      customDialogDetails.childrenList.push(temp[i].itemValue)
    }
    customDialogDetails.settingTitle = context.resourceManager.getStringSync(itemValue?.settingName?.id)
    if ((typeof itemValue.settingAlias) === 'string') {
      customDialogDetails.setAlias = itemValue.settingAlias
    } else {
      let tempSettingAlias = itemValue?.settingAlias
      customDialogDetails.setAlias = context.resourceManager.getStringSync(tempSettingAlias?.id)
    }
    this.setAPObj('customDialogDetails', customDialogDetails);
  }

}