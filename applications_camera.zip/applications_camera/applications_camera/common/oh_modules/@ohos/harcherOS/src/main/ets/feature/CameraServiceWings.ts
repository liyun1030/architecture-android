import { Log, Wings } from 'wings'
import { Options } from './Options'

const TAG = 'CameraServiceWings'

export class CameraServiceWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  public getPreviewProfile(previewProfiles, size): ESObject | undefined {
    if (!Options.isSupportUsbCamera()) {
      return undefined;
    }
    let previewProfile: any;
    previewProfile = previewProfiles.find(item => item.size.width === size.width &&
      item.size.height === size.height);
    if (!previewProfile) {
      previewProfile = previewProfiles[0];
    }
    return previewProfile;
  }

  public getPhotoProfile(photoProfiles, size): ESObject | undefined {
    if (!Options.isSupportUsbCamera()) {
      return undefined;
    }
    let photoProfile: any;
    photoProfile = photoProfiles.find(item => item.size.width === size.width && item.size.height === size.height);
    if (!photoProfile) {
      photoProfile = photoProfiles[0];
    }
    return photoProfile;
  }

  public getProfileVideo(videoProfiles, size) {
    if (!Options.isSupportUsbCamera()) {
      return undefined;
    }
    let profileVideo: any;
    profileVideo = videoProfiles.find(item =>
    item.size.width === size.width && item.size.height === size.height);
    if (!profileVideo) {
      profileVideo = videoProfiles[0];
    }
  }

  public initUsbCamera(cameraId, cameras): boolean | undefined {
    if (!Options.isSupportUsbCamera()) {
      return undefined;
    }
    let usbCamera;
    for (let i = 0; i < cameras.length; i++) {
      if (cameras[i].connectionType == 1) {
        AppStorage.setOrCreate('getUSBCamera', true);
        usbCamera = cameras[i];
        break;
      }
    }
    if (usbCamera) {
      let mLocalCameraMap: Map<string, string> = new Map();
      let mCameraIdMap: Map<string, string> = new Map();
      mLocalCameraMap.set('back', 'true');
      mCameraIdMap.set(cameraId.BACK, usbCamera.cameraId);
      this.setAPObj('mLocalCameraMap', mLocalCameraMap);
      this.setAPObj('mCameraIdMap', mCameraIdMap);
      return true;
    }
    return false;
  }

  public rotation() {
    if (!Options.isNeedRotation()) {
      return undefined;
    }
    this.getAPObj('mVideoConfig').rotation = 270;
  }
  

}