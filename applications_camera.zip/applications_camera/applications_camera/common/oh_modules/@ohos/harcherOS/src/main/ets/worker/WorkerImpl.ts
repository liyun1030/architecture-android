import { WorkerResultCode, workResult } from 'WorkerManager'

export enum WorkerMsg {
  // 命名规则 WORK_MSG_xxxxx
  WORK_MSG_XXX = 'test'
}

/**
 * 命名规则 funxxx,xxx和msg对应,需要按照大小驼峰规则进行命名的转换,这里定义完成后，需要在WingsWorker的workerImpl中进行注册
 */

export async function funXXX(data: ESObject): Promise<workResult> {
  let ret = new workResult(WorkerMsg.WORK_MSG_XXX)
  // TODO: 伪代码，判断参数正确
  let isParamValid = true
  if (!isParamValid) {
    ret.result = WorkerResultCode.PARAM_ERR
  } else {
    // 伪代码，这里自己写逻辑
    let ss = { aa: 2, bb: 'ccc' }
    ret.data = ss
    ret.result = WorkerResultCode.SUCCESS
  }
  // 伪代码，模拟耗时逻辑，此处可以是耗时逻辑
  await test()
  return ret
}

/**
 * 测试代码，此处为了模拟耗时逻辑
 * @returns
 */
async function test():Promise<void>{
  return new Promise<void>(res=>{
    setTimeout(()=>{
        res()
    },10000)
  })
}