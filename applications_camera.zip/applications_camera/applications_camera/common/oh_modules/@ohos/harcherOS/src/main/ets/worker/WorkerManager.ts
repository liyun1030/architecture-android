import { BaseWorkerManager, WorkerResultCode } from 'WorkerManager';
import worker from '@ohos.worker';
import { WorkerMsg } from './WorkerImpl';
import { Log } from 'wings';

const TAG = 'WorkerManager'
export class _WorkerManager extends BaseWorkerManager {
  bindWorker(): worker.ThreadWorker {
    return new worker.ThreadWorker('./WingsWorker.ts')
  }

  CallBack(msg: string, result: WorkerResultCode, data: any): void {
    Log.showInfo(TAG,`receive====\n msg:${msg}\n result:${result} \n data:${JSON.stringify(data)}\n==== from woker`)
    switch(msg) {
      case WorkerMsg.WORK_MSG_XXX:
      //TODO: 这里加上主线程相关处理逻辑
      break;
    }
  }

  private constructor() {
    super()
  }

  static instance: _WorkerManager

  static getInstance(): _WorkerManager {
    if (_WorkerManager.instance == undefined) {
      _WorkerManager.instance = new _WorkerManager()
    }
    return _WorkerManager.instance
  }
}

export const WorkerManager = _WorkerManager.getInstance()