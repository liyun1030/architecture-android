export class Options {
  // static isHarcherOS() {
  //   return true;
  // }
  static isSupportUsbCamera() {
    return true;
  }
  static isNeedRotation() {
    return true;
  }
  static isSupportPlaySound() {
    return true;
  }
  static isShowZoomView() {
    if (AppStorage.get('getUSBCamera')) {
      return false;
    }
    return true;
  }
  static isCanSetSystemBarEnable() {
    return true;
  }
  static isChangeZoomViewLandPosition() {
    return true;
  }
  static isChangeFootBarLandPosition() {
    return true;
  }
  static isTakingVideoCanvas() {
    return true;
  }
  static isRefreshCanvas() {
    return true;
  }
  static isGetZoomBtnCenterY() {
    return true;
  }
  static isFormatDate() {
    return true;
  }
  static isAppEventBusOn() {
    return true;
  }
  static isAppEventBusOff() {
    return true;
  }
  static isPinchGestureEnd() {
    return true;
  }
  static isShowZoomText() {
    return true;
  }
  static isFocus() {
    return true;
  }
  static isSwipeChangeMode() {
    return true;
  }
  static isShowCustomDialogView() {
    return true;
  }
  static isSettingListModel() {
    return true;
  }
  static isShowSettings() {
    return true;
  }
  static isSupportFlash() {
    if (AppStorage.get('getUSBCamera')) {
      return false;
    }
    return true;
  }
  static isSupportCameraSwitch() {
    if (AppStorage.get('getUSBCamera')) {
      return false;
    }
    return true;
  }
  static isSetFocus() {
    if (AppStorage.get('getUSBCamera')) {
      return false;
    }
    return true;
  }
  static isShowAllSettingsMenu() {
    return false;
  }
  static isSetSettingViewPadding() {
    return true;
  }
  static isAlignStart() {
    return true;
  }
  static isAlignCenter() {
    return true;
  }
  static isShowMultiMode() {
    return false;
  }
  static isShowIndicator() {
    return false;
  }
}