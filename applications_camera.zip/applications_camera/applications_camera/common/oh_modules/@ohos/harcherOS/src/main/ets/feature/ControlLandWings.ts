import { Log, Wings } from 'wings'
import { promptAction } from '@kit.ArkUI';

const TAG = 'ControlLandWings'

export class ControlLandWings extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

}