/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an 'AS IS' BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */

import worker, { ErrorEvent, MessageEvents, ThreadWorkerGlobalScope } from '@ohos.worker';
import { Log } from 'wings/Index';
import { workResult,WorkerResultCode } from 'WorkerManager';
import { funXXX, WorkerMsg} from './WorkerImpl';

const workerPort: ThreadWorkerGlobalScope = worker.workerPort
const TAG: string = 'WingsWorker'


/**
 * Defines the event handler to be called when the worker thread receives a message sent by the host thread.
 * The event handler is executed in the worker thread.
 *
 * @param e message data
 */
workerPort.onmessage = function (e: MessageEvents): void {
  let data = e.data;
  workerImpl(data).then(res=>{
    workerPort.postMessage(res)
  })
};

/**
 * Defines the event handler to be called when the worker receives a message that cannot be deserialized.
 * The event handler is executed in the worker thread.
 *
 * @param e message data
 */
workerPort.onmessageerror = function (e: MessageEvents): void {
  Log.showError(TAG, 'workPort: onmessageerror = ' + e.data)
};

/**
 * Defines the event handler to be called when an exception occurs during worker execution.
 * The event handler is executed in the worker thread.
 *
 * @param e error message
 */
workerPort.onerror = function (e: ErrorEvent): void {
  Log.showError(TAG, 'workPort: onerror = ' + e.message);
};

/**
 *
 * @param data
 * @returns
 */
async function workerImpl(data: ESObject): Promise<workResult> {
  let ret = new workResult(data.msg)
  if (data.msg == undefined) {
    ret.result = WorkerResultCode.ERR
    return ret
  }
  let isKeyValid:boolean = false
  for(let s in WorkerMsg){
    if(data.msg == WorkerMsg[s]) {
      isKeyValid = true
      break
    }
  }
  if (isKeyValid) {
    switch (data.msg) {
      case WorkerMsg.WORK_MSG_XXX:
        ret = await funXXX(data)
      break;
    }
  } else {
    ret.result = WorkerResultCode.MSG_NO_DEFINE
  }
  return ret
}
