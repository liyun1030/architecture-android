import hilog from '@ohos.hilog';
import { BUILD_MODE_NAME, HAR_VERSION } from '../../../../BuildProfileTS';
const DOMAIN = 0x001f;
const TAG = `Wings-Core(${HAR_VERSION}-${BUILD_MODE_NAME})`;
const SYMBOL = " --> ";
export class Log {
    static showInfo(y2, z2, ...a3) {
        if (Log.isLoggable(y2, hilog.LogLevel.INFO)) {
            hilog.info(DOMAIN, TAG, y2 + SYMBOL + z2, a3);
        }
    }
    static showDebug(v2, w2, ...x2) {
        if (Log.isLoggable(v2, hilog.LogLevel.DEBUG)) {
            hilog.debug(DOMAIN, TAG, v2 + SYMBOL + w2, x2);
        }
    }
    static showWarn(s2, t2, ...u2) {
        if (Log.isLoggable(s2, hilog.LogLevel.WARN)) {
            hilog.warn(DOMAIN, TAG, s2 + SYMBOL + t2, u2);
        }
    }
    static showError(p2, q2, ...r2) {
        if (Log.isLoggable(p2, hilog.LogLevel.ERROR)) {
            hilog.error(DOMAIN, TAG, p2 + SYMBOL + q2, r2);
        }
    }
    static showFatal(m2, n2, ...o2) {
        if (Log.isLoggable(m2, hilog.LogLevel.FATAL)) {
            hilog.fatal(DOMAIN, TAG, m2 + SYMBOL + n2, o2);
        }
    }
    static isLoggable(k2, l2) {
        return hilog.isLoggable(DOMAIN, k2, l2);
    }
    static recordStart(g2, h2) {
        let i2 = `${g2}-${h2}-${Math.floor(Math.random() * 100)}`;
        if (Log.isLoggable(g2, hilog.LogLevel.DEBUG)) {
            hilog.debug(DOMAIN, TAG, 'Function Follow:' + g2 + '.' + h2 + '=>Function Start');
            let j2 = Date.now();
            Log.funMap.set(i2, j2);
        }
        return i2;
    }
    static recordEnd(b2, c2, d2) {
        let e2;
        if (Log.isLoggable(b2, hilog.LogLevel.DEBUG)) {
            if (Log.funMap.has(d2)) {
                e2 = Log.funMap.get(d2);
            }
            else {
                hilog.debug(DOMAIN, TAG, 'Function Follow:' + b2 + '.' + c2 + '=>Function End (not record Start)');
                return;
            }
            let f2 = Date.now();
            hilog.debug(DOMAIN, TAG, 'Function Follow:' + b2 + '.' + c2 + `=>Function End (${f2 - e2}ms)`);
            Log.funMap.delete(d2);
        }
    }
}
Log.funMap = new Map();
