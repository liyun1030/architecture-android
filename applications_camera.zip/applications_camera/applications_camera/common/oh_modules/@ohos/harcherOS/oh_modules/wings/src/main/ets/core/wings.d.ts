export declare abstract class Wings {
    private _ins;
    constructor(a2: ESObject);
    Call(w1: (...x1: ESObject) => ESObject, ...x1: ESObject[]): ESObject;
    getAPObj(v1: string): ESObject;
    callAPFun(t1: string, ...u1: ESObject): ESObject;
    setAPObj(r1: string, s1: ESObject): void;
}
