import sysParam from '@ohos.systemParameterEnhance';
import { DeviceUtils } from '../utils/DeviceUtils';
import { Log } from '../utils/LogUtil';
const TAG = 'MemberHelper';
const LOG_LENGTH = 1800;
export class MemberHelper {
    static set isDebug(q1) {
        if (MemberHelper._isDebug == undefined) {
            MemberHelper._isDebug = q1;
        }
    }
    static set closeAll(p1) {
        MemberHelper._isCloseAll = p1;
    }
    static get closeAll() {
        return MemberHelper._isCloseAll;
    }
    static initEngine() {
        if (MemberHelper.productName == '') {
            MemberHelper.productName = sysParam.getSync("const.product.iname");
        }
        if (MemberHelper.chipName == '') {
            MemberHelper.chipName = sysParam.getSync("ohos.boot.hardware");
        }
    }
    get Ins() {
        return this._ins;
    }
    set processer(o1) {
        this._processer = o1;
    }
    static get supportChip() {
        MemberHelper.initEngine();
        return DeviceUtils.getAllChip();
    }
    CallNoReturn(k1, l1, ...m1) {
        if (MemberHelper._isCloseAll) {
            l1();
            return;
        }
        if (this._processer == undefined) {
            throw new Error(`wings_error CallNoReturn error: processer not init ready`);
        }
        if (k1 in this._processer) {
            let n1 = this._processer.Call(this._processer[k1], ...m1);
            if (typeof n1 == 'boolean') {
                if (!n1) {
                    l1();
                }
                return;
            }
            else {
                throw new Error(`wings_error CallNoReturn error: ${k1} is not return boolean`);
            }
        }
        throw new Error(`wings_error CallNoReturn error: ${k1} is not in processer`);
    }
    CallReturn(i1, ...j1) {
        if (MemberHelper._isCloseAll) {
            return undefined;
        }
        if (this._processer == undefined) {
            throw new Error(`wings_error CallReturn error: processer not init ready`);
        }
        if (i1 in this._processer) {
            return this._processer.Call(this._processer[i1], ...j1);
        }
        throw new Error(`wings_error CallReturn error: ${i1} is not in processer`);
    }
    delay(f1) {
        return new Promise(h1 => setTimeout(h1, f1));
    }
    CallNoReturnAsync(x, y, ...z) {
        return new Promise(async (b1, c1) => {
            if (MemberHelper._isCloseAll) {
                y();
                return;
            }
            for (let d1 = 0; d1 < 4; d1++) {
                if (this._processer != undefined) {
                    let e1 = this._processer.Call(this._processer[x], ...z);
                    if (typeof e1 == 'boolean') {
                        if (!e1) {
                            y();
                        }
                        return;
                    }
                    else {
                        throw new Error(`wings_error CallNoReturnAsync error: ${x} is not return boolean`);
                    }
                }
                if (d1 == 3) {
                    throw new Error(`wings_error CallNoReturnAsync error: processer init delay in 15ms`);
                }
                await this.delay(5);
            }
        });
    }
    CallReturnAsync(q, ...r) {
        return new Promise(async (t, u) => {
            if (MemberHelper._isCloseAll) {
                t(undefined);
                return;
            }
            for (let v = 0; v < 4; v++) {
                if (this._processer != undefined) {
                    let w = this._processer.Call(this._processer[q], ...r);
                    t(w);
                    return;
                }
                if (v == 3) {
                    throw new Error(`wings_error CallReturnAsync error: processer init delay in 15ms`);
                }
                await this.delay(5);
            }
        });
    }
    constructor(p) {
        this._ins = p;
    }
    static debugObj(l, m) {
        if (MemberHelper._isDebug) {
            if (m == undefined) {
                Log.showWarn(`wings debugObj=> {${l}}`, 'undefined');
                return;
            }
            if (JSON.stringify(m).length > LOG_LENGTH) {
                Log.showInfo(`wings debugObj=> {${l}}`, 'start');
            }
            for (let n = 0; n < (JSON.stringify(m).length / LOG_LENGTH); n++) {
                let o = (n + 1) * LOG_LENGTH > JSON.stringify(m).length ? JSON.stringify(m).length : (n + 1) * LOG_LENGTH;
                Log.showInfo(`wings debugObj=> {${l}}`, `${JSON.stringify(m).slice(0 + n * LOG_LENGTH, o)}`);
            }
            if (JSON.stringify(m).length > LOG_LENGTH) {
                Log.showInfo(`wings debugObj=> {${l}}`, 'end');
            }
        }
    }
    static debugArray(e, f) {
        if (MemberHelper._isDebug) {
            if (f instanceof Array) {
                f.forEach((h, i) => {
                    if (JSON.stringify(h).length > LOG_LENGTH) {
                        Log.showInfo(`wings debugArray=> {${e}}`, 'start');
                    }
                    for (let j = 0; j < (JSON.stringify(h).length / LOG_LENGTH); j++) {
                        let k = (j + 1) * LOG_LENGTH > JSON.stringify(h).length ? JSON.stringify(h).length : (j + 1) * LOG_LENGTH;
                        Log.showInfo(`wings debugArray=> {${e}}`, `[${i}] : ${JSON.stringify(h).slice(0 + j * LOG_LENGTH, k)}`);
                    }
                    if (JSON.stringify(h).length > LOG_LENGTH) {
                        Log.showInfo(`wings debugArray=> {${e}}`, 'end');
                    }
                });
            }
            else {
                Log.showWarn(`wings debugArray=> {${e}}`, 'not a array');
            }
        }
    }
    static debug(a, b) {
        if (MemberHelper._isDebug) {
            if (b == undefined) {
                Log.showWarn(`wings debug=> {${a}}`, 'undefined');
                return;
            }
            if (JSON.stringify(b).length > LOG_LENGTH) {
                Log.showInfo(`wings debug=> {${a}}`, 'start');
            }
            for (let c = 0; c < (JSON.stringify(b).length / LOG_LENGTH); c++) {
                let d = (c + 1) * LOG_LENGTH > JSON.stringify(b).length ? JSON.stringify(b).length : (c + 1) * LOG_LENGTH;
                Log.showInfo(`wings debug=> {${a}}`, `${JSON.stringify(b).slice(0 + c * LOG_LENGTH, d)}`);
            }
            if (JSON.stringify(b).length > LOG_LENGTH) {
                Log.showInfo(`wings debug=> {${a}}`, 'end');
            }
        }
    }
}
MemberHelper.productName = '';
MemberHelper.chipName = '';
MemberHelper._isCloseAll = false;
MemberHelper.sbr = undefined;
