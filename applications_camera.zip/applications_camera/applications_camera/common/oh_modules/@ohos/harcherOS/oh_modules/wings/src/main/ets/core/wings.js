import { Log } from "../utils/LogUtil";
const TAG = 'Wings';
export class Wings {
    constructor(a2) {
        this._ins = a2;
    }
    Call(w1, ...x1) {
        let y1 = Log.recordStart(this.constructor.name, w1.name);
        let z1 = w1.call(this, ...x1);
        Log.recordEnd(this.constructor.name, w1.name, y1);
        return z1;
    }
    getAPObj(v1) {
        if (v1 in this._ins) {
            return this._ins[v1];
        }
        throw new Error(`wings_error property error: ${this._ins.constructor.name} - [${v1}] not defined`);
    }
    callAPFun(t1, ...u1) {
        if (typeof (this._ins[t1]) != 'function') {
            throw new Error(`wings_error readFunction error: ${this._ins.constructor.name} - [${t1}] not a function`);
        }
        return this._ins[t1].call(this._ins, ...u1);
    }
    setAPObj(r1, s1) {
        if (r1 in this._ins) {
            if (typeof (this._ins[r1]) != 'function') {
                this._ins[r1] = s1;
                return;
            }
        }
        throw new Error(`wings_error property error: ${this._ins.constructor.name} - [${r1}] not defined or a function`);
    }
}
