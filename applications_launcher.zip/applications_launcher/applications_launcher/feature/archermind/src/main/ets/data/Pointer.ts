export class Pointer {
  row: number
  column: number

  constructor() {
    this.row = 0
    this.column = 0
  }
}