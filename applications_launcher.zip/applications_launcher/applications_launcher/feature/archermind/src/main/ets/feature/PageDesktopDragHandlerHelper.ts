import { Wings , Log} from "wings"
import { Pointer } from "../data/Pointer"
import { desktopLayoutData } from "../model/HarcherOSDesktopLayoutData";
import { PositionLayoutInfo } from "../data/PositionLayoutInfoBean"
import { Options } from "./Options"

const TAG: string = "PageDesktopDragHandlerHelper"

export class PageDesktopDragHandlerHelper extends Wings {
  private currentPointer: Pointer = new Pointer()

  constructor(ins: ESObject) {
    super(ins)
  }
  wingInitPosition(objectPositionCount){
    let obj = {};
    for (let [k, v] of objectPositionCount) {
      obj[k] = v;
    }
  }
  wingGetAutomaticAlignmentKey() {
    if (Options.isAlign()) {
      if (desktopLayoutData.getValue("AutomaticAlignment", "false") === "true") {
        const pageIndex: number = AppStorage.get('pageIndex') as number;
        for (let i = 0; i <= pageIndex; i++) {
          this.triggerIconAutoFill(i)
        }
      }
    }
  }

  public triggerIconAutoFill(pageNo: number) {
    // 自动对齐
    let info = this.getAPObj("mSettingsModel").getLayoutInfo()

    let layoutInfo = info.layoutInfo
    Log.showInfo(TAG,"all Positionsall Positions --"+JSON.stringify(layoutInfo))
    let allPositions = this.getAPObj("getAllPositions")(pageNo, layoutInfo) // 获取当前页所有位置信息
    this.sortAllPositions(allPositions)
    Log.showDebug(TAG, 'triggerIconAutoFill update layoutInfo ')
    const CommonConstants = this.getAPObj("Constants")
    for (let index = 0; index < layoutInfo.length; index++) {
      for (let row = allPositions.length - 1; row >= 0; row--) {
        for (let column = allPositions[row].length - 1; column >= 0; column--) {
          if (layoutInfo[index].typeId == CommonConstants.TYPE_APP && layoutInfo[index].keyName == allPositions[row][column].keyName ||
            layoutInfo[index].typeId == CommonConstants.TYPE_FOLDER && layoutInfo[index].folderId == allPositions[row][column].keyName ||
            layoutInfo[index].typeId == CommonConstants.TYPE_CARD && layoutInfo[index].cardId == allPositions[row][column].keyName) {
            layoutInfo[index].row = row;
            layoutInfo[index].column = column;
            layoutInfo[index].page = pageNo;
          }
        }
      }
    }
    Log.showDebug(TAG, 'triggerIconAutoFill end')

    console.info("zhu--layoutInfolayoutInfo--"+JSON.stringify(layoutInfo))
    info.layoutInfo = layoutInfo;
    this.getAPObj("mSettingsModel").setLayoutInfo(info);
    this.getAPObj("localEventManager").sendLocalEventSticky(this.getAPObj("EventConstants").EVENT_SMARTDOCK_INIT_FINISHED, null);
  }

  private sortAllPositions(allPositions: PositionLayoutInfo[][]) {
    this.currentPointer = { row: 0, column: 0 }
    this.setAPObj("mGridConfig",this.getAPObj("mSettingsModel").getGridConfig())
    let resultPositions: PositionLayoutInfo[][] = []
    this.getAPObj("setAllpositionsToNull")(resultPositions)
    let tmpList: Array<string> = []
    const CommonConstants = this.getAPObj("Constants")
    let filterUniqueUsedPositions: Array<PositionLayoutInfo> = [...allPositions.flat()]
      .filter(item => item.typeId !== CommonConstants.INVALID_VALUE)// 去除空白
      .filter(item =>!tmpList.includes(item.keyName) && tmpList.push(item.keyName)) // 去重(folder, card占用多格场景只统计一格)
    let currentPosition: PositionLayoutInfo = undefined
    let hasLayout: boolean = false
    while (filterUniqueUsedPositions.length > 0) {
      currentPosition = filterUniqueUsedPositions[0]
      if (resultPositions[this.currentPointer.row][this.currentPointer.column].typeId !== CommonConstants.INVALID_VALUE) {
        //位置已被占用，指针后移
        this.updateTraversePointer()
      } else if (!this.canLayout(currentPosition, resultPositions)) {
        hasLayout = false
        // 位置不足以放置当前元素，查找下一个能够放置的元素
        for (let index = 1; index < filterUniqueUsedPositions.length; index++) {
          currentPosition = filterUniqueUsedPositions[index]
          if (this.canLayout(currentPosition, resultPositions)) {
            this.layout(currentPosition, resultPositions)
            filterUniqueUsedPositions.splice(index, 1)
            this.updateTraversePointer()
            hasLayout = true
            break
          }
        }

        if (!hasLayout) {
          // 当前位置不足以放下后续任何元素
          this.updateTraversePointer()
        }
      } else {
        // 位置足够放置当前元素
        this.layout(currentPosition, resultPositions)
        filterUniqueUsedPositions.splice(0, 1)
        this.updateTraversePointer()
      }
    }

    for (let i = 0; i < resultPositions.length; i++) {
      allPositions[i] = resultPositions[i]
    }
  }
  private updateTraversePointer() {
    if (this.currentPointer.row < this.getAPObj('mGridConfig').row) {
      this.currentPointer.column++
      if (this.currentPointer.column >= this.getAPObj('mGridConfig').column) {
        this.currentPointer.column = 0
        this.currentPointer.row++
      }
    } else {
      this.currentPointer.row = this.getAPObj('mGridConfig').row
    }
  }
  private layout(currentPosition: PositionLayoutInfo, resultPositions: PositionLayoutInfo[][]) {
    // 放置元素，更新位置信息
    for (let tmpRow = 0; tmpRow < currentPosition.area[1]; tmpRow++) {
      for (let tmpColumn = 0; tmpColumn < currentPosition.area[0]; tmpColumn++) {
        resultPositions[this.currentPointer.row + tmpRow][this.currentPointer.column + tmpColumn] = currentPosition
      }
    }
  }
  private canLayout(currentPosition: PositionLayoutInfo, resultPositions: PositionLayoutInfo[][]) {
    const CommonConstants = this.getAPObj("Constants")
    // 判断待放置元素所申请区域是否已被占用
    let canLayout: boolean = true
    for (let tmpRow = 0; tmpRow < currentPosition.area[1]; tmpRow++) {
      for (let tmpColumn = 0; tmpColumn < currentPosition.area[0]; tmpColumn++) {
        if (this.currentPointer.row + tmpRow >= this.getAPObj('mGridConfig').row
          || this.currentPointer.column + tmpColumn >= this.getAPObj('mGridConfig').column
          || resultPositions[this.currentPointer.row + tmpRow][this.currentPointer.column + tmpColumn].typeId !== CommonConstants.INVALID_VALUE) {
          canLayout = false
          break
        }
      }
    }
    return canLayout
  }
}