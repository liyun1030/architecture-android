export class PositionLayoutInfo {
  public typeId: number = -1
  public keyName: string = ''
  public area: number[] = []

  constructor(typeId: number, keyName: string, area: number[]) {
    this.typeId = typeId
    this.keyName = keyName
    this.area = area
  }
}