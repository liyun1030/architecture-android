import dataShare from '@ohos.data.dataShare';
import { BusinessError } from '@ohos.base';
import settings from '@ohos.settings';
import { Context } from '@ohos.abilityAccessCtrl';
import { Log } from 'wings';

const DESK_LAYOUT: string = "deskLayout"
const TAG: string = "DesktopLayoutData"
const ICON_SIZE: string = "iconSize"
export class DesktopLayoutData {
  private dataShareHelper;
  private readonly uriShare = 'datashare:///com.ohos.settingsdata/entry/settingsdata/SETTINGSDATA?Proxy=true&key='

  /**
   * settingsData manager instance
   *
   * @return settingsDataManager instance
   */
  static getInstance(): DesktopLayoutData {
    if (!globalThis.DesktopLayoutDataInstance) {
      globalThis.DesktopLayoutDataInstance = new DesktopLayoutData();
    }
    return globalThis.DesktopLayoutDataInstance;
  }

  createDataShareHelper(type,callback) {
    let url = this.uriShare + (type === 1 ? DESK_LAYOUT : ICON_SIZE)
    Log.showInfo(TAG, 'createDataShareHelper context url:' + url);
    dataShare.createDataShareHelper(globalThis.desktopContext, url)
      .then((dataHelper) => {
        Log.showInfo(TAG, `createDataShareHelper success.`);
        this.dataShareHelper = dataHelper;
        this.dataShareHelper.on("dataChange", url, (error) => {
          Log.showInfo(TAG, "dataChange success");
          callback()
        })
      })
      .catch((err: BusinessError) => {
        Log.showError(TAG, `createDataShareHelper fail. ${JSON.stringify(err)}`);
      });

  }

  /**
   * Update settingData by settingDataKey.
   */
  setValue(settingDataKey: string, value: string): void {
    Log.showInfo(TAG, "setValue:" + value)
    if (typeof globalThis.desktopContext === 'undefined') {
      settings.setValueSync(globalThis.settingsContext as Context, settingDataKey, value);
    } else {
      settings.setValueSync(globalThis.desktopContext as Context, settingDataKey, value);
    }
  }

  /**
   * get settingDataValue by settingDataKey.
   *
   * @return settingsDataValue by settingDataKey.
   */
  getValue(settingDataKey: string, defaultValue: string): string {
    let value: string = '1';
    if (typeof globalThis.desktopContext === 'undefined') {
      value = settings.getValueSync(globalThis.settingsContext as Context, settingDataKey, defaultValue);
    } else {
      value = settings.getValueSync(globalThis.desktopContext as Context, settingDataKey, defaultValue);
    }
    Log.showInfo(TAG, "getValue:" + value);
    return value;
  }
}

export const desktopLayoutData = DesktopLayoutData.getInstance();