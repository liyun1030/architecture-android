export class Options {
  static  isAlign() {
    return true
  }
}