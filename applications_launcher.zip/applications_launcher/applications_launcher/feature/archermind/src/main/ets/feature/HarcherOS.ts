import { Log, MemberHelper } from 'wings'

const IMPORT_TAG = 'HarcherOS_import'

export class HarcherOS extends MemberHelper {
  constructor(ins: ESObject) {
    super(ins)
  }

  public init(instanceName: string): HarcherOS {
    // 这里要在程序里写好import的值,这里需要提前找好对应关系,否则会出现问题
    let tag = Log.recordStart(IMPORT_TAG, instanceName)
    switch (instanceName) {
      case 'SwiperPage':
        import('./SwiperPageHelper').then(res => {
          this.processer = new res.SwiperPageHelper(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
        case 'PageDesktopDragHandler':
          import('./PageDesktopDragHandlerHelper').then(res => {
            this.processer = new res.PageDesktopDragHandlerHelper(this.Ins)
            Log.recordEnd(IMPORT_TAG, instanceName, tag)
          })
          break;
      case 'PageDesktopViewModel':
        import('./PageDesktopViewModelHelper').then(res => {
          this.processer = new res.PageDesktopViewModelHelper(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
    }
    return this
  }
}

HarcherOS.isDebug = true
// 关闭所有特性
HarcherOS.closeAll = false