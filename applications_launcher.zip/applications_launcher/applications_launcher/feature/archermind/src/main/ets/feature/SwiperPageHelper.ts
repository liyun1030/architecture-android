import { Wings, Log } from "wings"
import { lockedAndAlignAtLayout } from "../model/HarcherOSLockedAndAlignAtLayout";
import { Options } from "./Options"


const TAG: string = "SwiperPageHelper"

export class SwiperPageHelper extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  wingCreateDataShareHelper() {
    if (Options.isAlign()) {
      lockedAndAlignAtLayout.createDataShareHelper(2, (value: boolean) => {
        Log.showInfo(TAG, 'Automatic alignment value --->' + value);
        if (value) {
          const pageDesktopDragHandler = this.getAPObj("PageDesktopDragHandlerHarcher")
          const pageIndex: number = AppStorage.get('pageIndex') as number;
          for (let i = 0; i <= pageIndex; i++) {
            pageDesktopDragHandler.triggerIconAutoFill(i)
          }
        }
      })
    }
  }
}