import dataShare from '@ohos.data.dataShare';
import { BusinessError } from '@ohos.base';
import settings from '@ohos.settings';
import common from '@ohos.app.ability.common';
import { Log } from 'wings';


const TAG: string = "lockedLayout"
const LOCKED_LAYOUT: string = "lockedLayout"
const AUTOMATIC_ALIGNMENT: string = "AutomaticAlignment"

export class LockedAndAlignAtLayout {
  private dataShareHelper;
  private readonly uriShare = 'datashare:///com.ohos.settingsdata/entry/settingsdata/SETTINGSDATA?Proxy=true&key=';

  /**
   * settingsData manager instance
   *
   * @return settingsDataManager instance
   */
  static getInstance(): LockedAndAlignAtLayout {
    if (!globalThis.LockedAndAlignAtLayoutInstance) {
      globalThis.LockedAndAlignAtLayoutInstance = new LockedAndAlignAtLayout();
    }
    return globalThis.LockedAndAlignAtLayoutInstance;
  }

  createDataShareHelper(type, callback) {
    Log.showInfo(TAG, 'createDataShareHelper context:' + globalThis.desktopContext);
    let url = this.uriShare + (type === 1 ? LOCKED_LAYOUT : AUTOMATIC_ALIGNMENT)
    dataShare.createDataShareHelper(globalThis.desktopContext, url)
      .then((dataHelper) => {
        Log.showInfo(TAG, `createDataShareHelper success.`);
        this.dataShareHelper = dataHelper;
        this.dataShareHelper.on("dataChange", url, (error) => {
          Log.showInfo(TAG, "dataChange success");
          if (type === 1) {
            let value = settings.getValueSync(globalThis.desktopContext as common.Context, LOCKED_LAYOUT, "false")
            callback(JSON.parse(value))
          } else {
            let value = settings.getValueSync(globalThis.desktopContext as common.Context, AUTOMATIC_ALIGNMENT, "false")
            callback(JSON.parse(value))
          }
        })
      })
      .catch((err: BusinessError) => {
        Log.showError(TAG, `createDataShareHelper fail. ${JSON.stringify(err)}`);
      });
  }
}

export const lockedAndAlignAtLayout = LockedAndAlignAtLayout.getInstance();