import { Wings } from "wings";
import settings from '@ohos.settings';
import { Context } from '@ohos.abilityAccessCtrl';

const AUTOMATIC_ALIGNMENT: string = "AutomaticAlignment"
const TAG: string = "PageDesktopViewModelHelper"

export class PageDesktopViewModelHelper extends Wings {
  constructor(ins: ESObject) {
    super(ins)
  }

  wingIconAutoFill() {
    let value = settings.getValueSync(globalThis.desktopContext as Context, AUTOMATIC_ALIGNMENT, "false")
    if (value === 'true') { //自动对齐
      const pageDesktopDragHandler = this.getAPObj("PageDesktopDragHandler")
      pageDesktopDragHandler.triggerIconAutoFill(AppStorage.get("pageIndex"))
    }
  }
}