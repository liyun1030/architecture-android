/**
 * Copyright (c) 2021-2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { 
  Log,
  BaseDragHandler,
  CommonConstants,
  CheckEmptyUtils,
  SettingsModel,
  EventConstants,
  localEventManager,
  layoutConfigManager,
  PageDesktopModel
} from '@ohos/common';
import type {
  LauncherDragItemInfo,
  DragArea,
  DragItemPosition
} from '@ohos/common';
import { FormViewModel } from '@ohos/form';
import { BigFolderViewModel } from '@ohos/bigfolder';
import { PageDesktopGridStyleConfig } from './PageDesktopGridStyleConfig';
import PageDesktopConstants from './constants/PageDesktopConstants'
import { HarcherOS } from '@ohos/harcherOS';

const TAG = 'PageDesktopDragHandler';

class PositionLayoutInfo {
  public typeId: number = -1
  public keyName: string = ''
  public area: number[] = []

  constructor(typeId: number, keyName: string, area: number[]) {
    this.typeId = typeId
    this.keyName = keyName
    this.area = area
  }
}

/**
 * Desktop workspace drag and drop processing class
 */
export class PageDesktopDragHandler extends BaseDragHandler {
  private harcherOS: HarcherOS = new HarcherOS(this).init('PageDesktopDragHandler')
  private Constants:CommonConstants
  private localEventManager
  private EventConstants
  private readonly mPageDesktopStyleConfig: PageDesktopGridStyleConfig;
  private readonly mBigFolderViewModel: BigFolderViewModel;
  private readonly mFormViewModel: FormViewModel;
  private readonly mSettingsModel: SettingsModel;
  private readonly mPageDesktopModel: PageDesktopModel;
  private mGridConfig;
  private mPageCoordinateData = {
    gridXAxis: [],
    gridYAxis: []
  };
  mStartPosition: DragItemPosition;
  private mEndPosition: DragItemPosition;
  private readonly styleConfig;
  private mGridItemHeight: number;
  private mGridItemWidth: number;

  private constructor() {
    super();
    this.mBigFolderViewModel = BigFolderViewModel.getInstance();
    this.mSettingsModel = SettingsModel.getInstance();
    this.mFormViewModel = FormViewModel.getInstance();
    this.mPageDesktopModel = PageDesktopModel.getInstance();
    this.mPageDesktopStyleConfig = layoutConfigManager.getStyleConfig(PageDesktopGridStyleConfig.APP_GRID_STYLE_CONFIG,
      PageDesktopConstants.FEATURE_NAME);
  }

  static getInstance(): PageDesktopDragHandler {
    if (globalThis.PageDesktopDragHandler == null) {
      globalThis.PageDesktopDragHandler = new PageDesktopDragHandler();
    }
    return globalThis.PageDesktopDragHandler;
  }

  setDragEffectArea(effectArea): void {
    Log.showDebug(TAG, `setDragEffectArea:${JSON.stringify(effectArea)}`)
    AppStorage.setOrCreate('pageDesktopDragEffectArea', effectArea);
    super.setDragEffectArea(effectArea);
    this.updateGridParam(effectArea);
  }

  isDragEffectArea(x: number, y: number): boolean {
    const isInEffectArea = super.isDragEffectArea(x, y);
    Log.showDebug(TAG, `isDragEffectArea x: ${x}, y: ${y}, isInEffectArea: ${isInEffectArea}`);
    const deviceType: string = AppStorage.get('deviceType');
    const smartDockDragEffectArea: DragArea = AppStorage.get('smartDockDragEffectArea');
    Log.showDebug(TAG, `isDragEffectArea smartDockDragEffectArea: ${JSON.stringify(smartDockDragEffectArea)}`);
    if (smartDockDragEffectArea) {
      if (deviceType == CommonConstants.DEFAULT_DEVICE_TYPE) {
        if (isInEffectArea || (y <= smartDockDragEffectArea.bottom && y >= smartDockDragEffectArea.top)
        && x <= smartDockDragEffectArea.right && x >= smartDockDragEffectArea.left) {
          return true;
        }
        return false;
      }
      return isInEffectArea;
    }
    return false;
  }

  getRow(index: number): number {
    return ~~(index / this.mSettingsModel.getGridConfig().column);
  }

  getColumn(index: number): number {
    return index % this.mSettingsModel.getGridConfig().column;
  }

  private updateGridParam(effectArea: DragArea): void {
    const gridWidth = this.mPageDesktopStyleConfig.mGridWidth;
    const gridHeight = this.mPageDesktopStyleConfig.mGridHeight;
    Log.showDebug(TAG, `updateGridParam gridWidth: ${gridWidth}, gridHeight: ${gridHeight}`);
    this.mGridConfig = this.mSettingsModel.getGridConfig();
    const column = this.mGridConfig.column;
    const row = this.mGridConfig.row;
    const columnsGap =  this.mPageDesktopStyleConfig.mColumnsGap;
    const rowGap =  this.mPageDesktopStyleConfig.mRowsGap;
    this.mGridItemHeight = row > 0 ? (gridHeight + columnsGap) / row : 0;
    this.mGridItemWidth = column > 0 ? (gridWidth + rowGap) / column : 0;
    Log.showDebug(TAG, `updateGridParam column: ${column}, row: ${row}`);
    this.mPageCoordinateData.gridYAxis = [];
    for (let i = 1; i <= row; i++) {
      const touchPositioningY = (gridHeight / row) * i + effectArea.top;
      this.mPageCoordinateData.gridYAxis.push(touchPositioningY);
    }

    this.mPageCoordinateData.gridXAxis = [];
    for (let i = 1; i <= column; i++) {
      const touchPositioningX = (gridWidth / column) * i + effectArea.left;
      this.mPageCoordinateData.gridXAxis.push(touchPositioningX);
    }
  }

  protected getDragRelativeData(): any {
    const desktopDataInfo: {
      appGridInfo: [[]]
    } = AppStorage.get('appListInfo');
    return desktopDataInfo.appGridInfo;
  }

  getItemIndex(x: number, y: number): number {
    Log.showInfo(TAG, `getItemIndex x: ${x}, y: ${y}`);
    let rowVal = CommonConstants.INVALID_VALUE;
    for (let index = 0; index < this.mPageCoordinateData.gridYAxis.length; index++) {
      if (this.mPageCoordinateData.gridYAxis[index] > y) {
        rowVal = index;
        break;
      }
    }
    let columnVal = CommonConstants.INVALID_VALUE;
    for (let index = 0; index < this.mPageCoordinateData.gridXAxis.length; index++) {
      if (this.mPageCoordinateData.gridXAxis[index] > x) {
        columnVal = index;
        break;
      }
    }
    const column = this.mGridConfig.column;
    if (rowVal != CommonConstants.INVALID_VALUE && columnVal != CommonConstants.INVALID_VALUE) {
      return rowVal * column + columnVal;
    }
    return CommonConstants.INVALID_VALUE;
  }

  protected getItemByIndex(index: number): any {
    const column = index % this.mGridConfig.column;
    const row = Math.floor(index / this.mGridConfig.column);
    const pageIndex: number = AppStorage.get('pageIndex');
    const appGridInfo = this.getDragRelativeData();
    Log.showInfo(TAG, `getItemByIndex pageIndex: ${pageIndex}, appGridInfo length: ${appGridInfo.length},
    column: ${column}, row: ${row}`);
    const itemInfo = appGridInfo[pageIndex].find(item => {
      if (item.typeId == CommonConstants.TYPE_APP) {
        return item.column == column && item.row == row;
      } else if (item.typeId == CommonConstants.TYPE_FOLDER || item.typeId == CommonConstants.TYPE_CARD) {
        return this.isItemInRowColumn(row, column, item);
      }
    });
    return itemInfo;
  }

  /**
   * judge the item is at target row and column
   * @param row
   * @param column
   * @param item
   */
  private isItemInRowColumn(row: number, column: number, item: any): boolean {
    return item.column <= column && column < item.column + item.area[0] && item.row <= row && row < item.row + item.area[1];
  }

  getTouchPosition(x: number, y: number): DragItemPosition {
    const pageIndex: number = AppStorage.get('pageIndex');
    Log.showDebug(TAG, `getTouchPosition pageIndex: ${pageIndex}`);
    const position: DragItemPosition = {
      page: pageIndex,
      row: 0,
      column: 0,
      X: x,
      Y: y,
    };
    for (let i = 0; i < this.mPageCoordinateData.gridXAxis.length; i++) {
      if (x < this.mPageCoordinateData.gridXAxis[i]) {
        position.column = i;
        break;
      } else {
        position.column = this.mPageCoordinateData.gridXAxis.length - 1;
      }
    }
    for (let i = 0; i < this.mPageCoordinateData.gridYAxis.length; i++) {
      if (y < this.mPageCoordinateData.gridYAxis[i]) {
        position.row = i;
        break;
      } else {
        position.row = this.mPageCoordinateData.gridYAxis.length - 1;
      }
    }
    return position;
  }

  onDragStart(x: number, y: number): void {
    this.mStartPosition = null;
    Log.showInfo(TAG, 'onDragStart start');
    const selectAppIndex = this.getItemIndex(x, y);
    AppStorage.setOrCreate('selectAppIndex', selectAppIndex);
    this.mStartPosition = this.getTouchPosition(x, y);
  }

  onDragDrop(x: number, y: number): boolean {
    const dragItemInfo: LauncherDragItemInfo = AppStorage.get<LauncherDragItemInfo>('dragItemInfo');
    if (!dragItemInfo.isDragging) {
      return false;
    }
    const dragItemType: number = AppStorage.get('dragItemType');
    const deviceType: string = AppStorage.get('deviceType')
    // dock appInfo has no location information.
    if (dragItemType === CommonConstants.DRAG_FROM_DOCK && deviceType == CommonConstants.DEFAULT_DEVICE_TYPE) {
      dragItemInfo.typeId = CommonConstants.TYPE_APP;
      dragItemInfo.area = [1, 1];
      dragItemInfo.page = AppStorage.get('pageIndex');
    }
    Log.showDebug(TAG, `onDragEnd dragItemInfo: ${JSON.stringify(dragItemInfo)}`);
    const endIndex = this.getItemIndex(x, y);
    const startPosition: DragItemPosition = this.copyPosition(this.mStartPosition);
    let endPosition: DragItemPosition = null;
    this.mEndPosition = this.getTouchPosition(x, y);
    Log.showDebug(TAG, `onDragEnd mEndPosition: ${JSON.stringify(this.mEndPosition)}`);
    endPosition = this.copyPosition(this.mEndPosition);
    const info = this.mSettingsModel.getLayoutInfo();
    const layoutInfo = info.layoutInfo;
    if (dragItemInfo.typeId == CommonConstants.TYPE_FOLDER || dragItemInfo.typeId == CommonConstants.TYPE_CARD) {
      this.updateEndPosition(dragItemInfo);
    } else {
      if (this.isMoveToSamePosition(dragItemInfo)) {
        this.deleteBlankPageAfterDragging(startPosition, endPosition);
        return false;
      }
      const endLayoutInfo = this.getEndLayoutInfo(layoutInfo);
      if (endLayoutInfo != undefined) {
        // add app to folder
        if (endLayoutInfo.typeId === CommonConstants.TYPE_FOLDER) {
          this.mBigFolderViewModel.addOneAppToFolder(dragItemInfo, endLayoutInfo.folderId);
          if (dragItemType === CommonConstants.DRAG_FROM_DOCK && deviceType == CommonConstants.DEFAULT_DEVICE_TYPE) {
            localEventManager.sendLocalEventSticky(EventConstants.EVENT_REQUEST_RESIDENT_DOCK_ITEM_DELETE, dragItemInfo);
          }
          this.deleteBlankPageAfterDragging(startPosition, endPosition);
          return true;
        } else if (endLayoutInfo.typeId === CommonConstants.TYPE_APP) {
          // create a new folder
          const layoutInfoList = [endLayoutInfo];
          let startLayoutInfo = null;
          if (dragItemType === CommonConstants.DRAG_FROM_DOCK && deviceType == CommonConstants.DEFAULT_DEVICE_TYPE) {
            let appInfoList = this.mSettingsModel.getAppListInfo();
            const appIndex = appInfoList.findIndex(item => {
              return item.keyName === dragItemInfo.keyName;
            })
            if (appIndex == CommonConstants.INVALID_VALUE) {
              appInfoList.push({
                "appName": dragItemInfo.appName,
                "isSystemApp": dragItemInfo.isSystemApp,
                "isUninstallAble": dragItemInfo.isUninstallAble,
                "appIconId": dragItemInfo.appIconId,
                "appLabelId": dragItemInfo.appLabelId,
                "bundleName": dragItemInfo.bundleName,
                "abilityName": dragItemInfo.abilityName,
                "moduleName": dragItemInfo.moduleName,
                "keyName": dragItemInfo.keyName,
                "typeId": dragItemInfo.typeId,
                "area": dragItemInfo.area,
                "page": dragItemInfo.page,
                "column": this.getColumn(endIndex),
                "row": this.getRow(endIndex),
                "x": 0,
                "installTime": dragItemInfo.installTime,
                "badgeNumber": dragItemInfo.badgeNumber
              })
              this.mSettingsModel.setAppListInfo(appInfoList);
            }
            startLayoutInfo = dragItemInfo;
            localEventManager.sendLocalEventSticky(EventConstants.EVENT_REQUEST_RESIDENT_DOCK_ITEM_DELETE, dragItemInfo);
          } else {
            startLayoutInfo = this.getStartLayoutInfo(layoutInfo, dragItemInfo);
          }
          layoutInfoList.push(startLayoutInfo);
          this.mBigFolderViewModel.addNewFolder(layoutInfoList).then(()=> {
            this.deleteBlankPageAfterDragging(startPosition, endPosition);
          });
          return true;
        } else if (endLayoutInfo.typeId === CommonConstants.TYPE_CARD) {
          if (dragItemType === CommonConstants.DRAG_FROM_DOCK && deviceType == CommonConstants.DEFAULT_DEVICE_TYPE) {
            localEventManager.sendLocalEventSticky(EventConstants.EVENT_REQUEST_PAGEDESK_ITEM_ADD, dragItemInfo);
            localEventManager.sendLocalEventSticky(EventConstants.EVENT_REQUEST_RESIDENT_DOCK_ITEM_DELETE, dragItemInfo);
            localEventManager.sendLocalEventSticky(EventConstants.EVENT_SMARTDOCK_INIT_FINISHED, null);
            return true;
          }
        }
      }
    }

    if (dragItemType === CommonConstants.DRAG_FROM_DOCK && deviceType == CommonConstants.DEFAULT_DEVICE_TYPE) {
      let appInfoTemp = {
        "bundleName": dragItemInfo.bundleName,
        "typeId": dragItemInfo.typeId,
        "abilityName": dragItemInfo.abilityName,
        "moduleName": dragItemInfo.moduleName,
        "keyName": dragItemInfo.keyName,
        "area": dragItemInfo.area,
        "page": dragItemInfo.page,
        "column": this.getColumn(endIndex),
        "row": this.getRow(endIndex),
        "badgeNumber": dragItemInfo.badgeNumber
      };
      layoutInfo.push(appInfoTemp as LauncherDragItemInfo);
      localEventManager.sendLocalEventSticky(EventConstants.EVENT_REQUEST_RESIDENT_DOCK_ITEM_DELETE, dragItemInfo);
    } else {
      this.checkAndMove(this.mStartPosition, this.mEndPosition, layoutInfo, dragItemInfo);
    }

    info.layoutInfo = layoutInfo;
    this.mSettingsModel.setLayoutInfo(info);
    localEventManager.sendLocalEventSticky(EventConstants.EVENT_SMARTDOCK_INIT_FINISHED, null);
    this.deleteBlankPageAfterDragging(startPosition, endPosition);
    return true;
  }

  private updateEndPosition(dragItemInfo: LauncherDragItemInfo): void {
    this.mGridConfig = this.mSettingsModel.getGridConfig();
    if (this.mEndPosition.row < 0) {
      this.mEndPosition.row = 0;
    } else if (this.mEndPosition.row + dragItemInfo.area[1] > this.mGridConfig.row) {
      this.mEndPosition.row = this.mGridConfig.row - dragItemInfo.area[1];
    }
    if (this.mEndPosition.column < 0) {
      this.mEndPosition.column = 0;
    } else if (this.mEndPosition.column + dragItemInfo.area[0] > this.mGridConfig.column ) {
      this.mEndPosition.column = this.mGridConfig.column - dragItemInfo.area[0];
    }
  }

  deleteBlankPageOutsideEffect() {
    // delete Blank Page because of drag outside effect area
    Log.showInfo(TAG, 'deleteBlankPageOutsideEffect' );
    const startPosition: DragItemPosition = this.copyPosition(this.mStartPosition);
    this.deleteBlankPageAfterDragging(startPosition, startPosition);
  }

  /**
   * copy a new position object by original position
   *
   * @param position - original position
   */
  private copyPosition(position: DragItemPosition): DragItemPosition {
    if (CheckEmptyUtils.isEmpty(position)) {
      return null;
    }
    const directionPosition: DragItemPosition = {
      page: position.page,
      row: position.row,
      column: position.column,
      X: position.X,
      Y: position.Y
    };
    return directionPosition;
  }

  /**
   * delete blank page after dragging
   *
   * @param startPosition - drag start position
   * @param endPosition - drag end position
   */
  deleteBlankPageAfterDragging(startPosition: DragItemPosition, endPosition: DragItemPosition): void {
    const layoutInfo = this.mSettingsModel.getLayoutInfo();
    const pageCount = layoutInfo.layoutDescription.pageCount;
    const isAddByDraggingFlag = this.mPageDesktopModel.isAddByDragging();
    let deleteLastFlag = false;
    if (isAddByDraggingFlag && (CheckEmptyUtils.isEmpty(endPosition) ||
    !CheckEmptyUtils.isEmpty(endPosition) && endPosition.page != pageCount - 1 )) {
      layoutInfo.layoutDescription.pageCount = pageCount - 1;
      deleteLastFlag = true;
    }
    let deleteStartFlag = false;
    if (!CheckEmptyUtils.isEmpty(startPosition)) {
      deleteStartFlag = this.mPageDesktopModel.deleteBlankPageFromLayoutInfo(layoutInfo, startPosition.page);
    }
    if (CheckEmptyUtils.isEmpty(endPosition) || JSON.stringify(startPosition) === JSON.stringify(endPosition)) {
      Log.showDebug(TAG, `pageIndex: ${JSON.stringify(startPosition) === JSON.stringify(endPosition)}`);
      AppStorage.setOrCreate('pageIndex', startPosition.page);
    } else if (deleteStartFlag) {
      if (startPosition.page > endPosition.page) {
        AppStorage.setOrCreate('pageIndex', endPosition.page);
      } else if (endPosition.page > startPosition.page &&
      endPosition.page < layoutInfo.layoutDescription.pageCount) {
        AppStorage.setOrCreate('pageIndex', endPosition.page - 1);
      }
    }
    this.mPageDesktopModel.setAddByDragging(false);
    if (deleteLastFlag || deleteStartFlag) {
      this.mSettingsModel.setLayoutInfo(layoutInfo);
      localEventManager.sendLocalEventSticky(EventConstants.EVENT_REQUEST_PAGEDESK_REFRESH, null);
    }
  }

  private isMoveToSamePosition(dragItemInfo: LauncherDragItemInfo): boolean {
    if (this.mEndPosition.page == dragItemInfo.page &&
    this.mEndPosition.row == dragItemInfo.row && this.mEndPosition.column == dragItemInfo.column) {
      return true;
    }
    return false;
  }

  private getEndLayoutInfo(layoutInfo) {
    const endLayoutInfo = layoutInfo.find(item => {
      if (item.typeId == CommonConstants.TYPE_FOLDER || item.typeId == CommonConstants.TYPE_CARD) {
        return item.page === this.mEndPosition.page && this.isItemInRowColumn(this.mEndPosition.row, this.mEndPosition.column, item);
      } else if (item.typeId == CommonConstants.TYPE_APP) {
        return item.page === this.mEndPosition.page && item.row === this.mEndPosition.row && item.column === this.mEndPosition.column;
      }
    });
    return endLayoutInfo;
  }

  private getStartLayoutInfo(layoutInfo, dragItemInfo: LauncherDragItemInfo): LauncherDragItemInfo {
    const startLayoutInfo = layoutInfo.find(item => {
      return item.page === dragItemInfo.page && item.row === dragItemInfo.row && item.column === dragItemInfo.column;
    });
    return startLayoutInfo;
  }

  /**
   * folder squeeze handle
   * @param source
   * @param destination
   * @param layoutInfo
   * @param dragItemInfo
   */
  private checkAndMove(source, destination, layoutInfo, dragItemInfo: LauncherDragItemInfo): boolean {
    Log.showDebug(TAG, 'checkAndMove start');

    const allPositions = this.getAllPositions(destination, layoutInfo);
    const objectPositionCount = this.getObjectPositionCount(destination, layoutInfo);
    this.harcherOS.CallReturn('wingInitPosition',objectPositionCount)
    const pressedPositions = this.getPressedObjects(destination, allPositions, dragItemInfo);

    // source and destination is in the same page
    if (source.page == destination.page && !this.checkCanMoveInSamePage(pressedPositions, objectPositionCount, dragItemInfo)) {
      return false;
    }
    // source and destination is in diff page
    if (source.page != destination.page && !this.checkCanMoveInDiffPage(allPositions, dragItemInfo)) {
      return false;
    }

    if (source.page == destination.page) {
      this.setSourcePositionToNull(dragItemInfo, allPositions);
    }
    this.setDestinationPosition(destination, allPositions, dragItemInfo);

    Log.showDebug(TAG, `checkAndMove pressedPositions.foldersAndForms: ${pressedPositions.foldersAndForms.length}`);
    if (pressedPositions.foldersAndForms.length != 0) {
      if (!this.moveFoldersAndForms(pressedPositions.foldersAndForms, destination, allPositions, dragItemInfo)) {
        return false;
      }
    }
    Log.showDebug(TAG, `checkAndMove pressedPositions.apps.length: ${pressedPositions.apps.length}`);
    if (pressedPositions.apps.length != 0) {
      this.moveApps(pressedPositions.apps, allPositions);
    }
    Log.showDebug(TAG, 'checkAndMove update destination ');
    this.updateDestinationByDragItem(dragItemInfo, destination, allPositions);
    Log.showDebug(TAG, 'checkAndMove update layoutInfo ');
    for (let index = 0; index < layoutInfo.length; index++) {
      for (let row = allPositions.length - 1; row >= 0 ; row--) {
        for (let column = allPositions[row].length - 1; column >= 0 ; column--) {
          if (layoutInfo[index].typeId == CommonConstants.TYPE_APP && layoutInfo[index].keyName == allPositions[row][column].keyName ||
          layoutInfo[index].typeId == CommonConstants.TYPE_FOLDER && layoutInfo[index].folderId == allPositions[row][column].keyName ||
          layoutInfo[index].typeId == CommonConstants.TYPE_CARD && layoutInfo[index].cardId == allPositions[row][column].keyName) {
            layoutInfo[index].row = row;
            layoutInfo[index].column = column;
            layoutInfo[index].page = destination.page;
          }
        }
      }
    }
    this.harcherOS.CallReturn('wingGetAutomaticAlignmentKey')
    Log.showDebug(TAG, 'checkAndMove end');
    return true;
  }

  //Begin zhuxiandi/n021839 <feat>  Wings功能回合桌面图标自动对其功能
  public triggerIconAutoFill(pageNo: number) {
    // 自动对齐
    let info = this.mSettingsModel.getLayoutInfo()

    let layoutInfo = info.layoutInfo
    console.info("zhu--allPositionsallPositions11--"+JSON.stringify(layoutInfo))
    let allPositions = this.getAllPositions(pageNo, layoutInfo) // 获取当前页所有位置信息
    console.info("zhu--allPositionsallPositions--"+JSON.stringify(allPositions))
    this.sortAllPositions(allPositions)
    Log.showDebug(TAG, 'triggerIconAutoFill update layoutInfo ')
    for (let index = 0; index < layoutInfo.length; index++) {
      for (let row = allPositions.length - 1; row >= 0; row--) {
        for (let column = allPositions[row].length - 1; column >= 0; column--) {
          if (layoutInfo[index].typeId == CommonConstants.TYPE_APP && layoutInfo[index].keyName == allPositions[row][column].keyName ||
            layoutInfo[index].typeId == CommonConstants.TYPE_FOLDER && layoutInfo[index].folderId == allPositions[row][column].keyName ||
            layoutInfo[index].typeId == CommonConstants.TYPE_CARD && layoutInfo[index].cardId == allPositions[row][column].keyName) {
            layoutInfo[index].row = row;
            layoutInfo[index].column = column;
            layoutInfo[index].page = pageNo;
          }
        }
      }
    }
    Log.showDebug(TAG, 'triggerIconAutoFill end')

    console.info("zhu--layoutInfolayoutInfo--"+JSON.stringify(layoutInfo))
    info.layoutInfo = layoutInfo;
    this.mSettingsModel.setLayoutInfo(info);
    localEventManager.sendLocalEventSticky(EventConstants.EVENT_SMARTDOCK_INIT_FINISHED, null);
  }

  private currentPointer = { row: 0, column: 0 }

  private sortAllPositions(allPositions: PositionLayoutInfo[][]) {
    this.currentPointer = { row: 0, column: 0 }
    this.mGridConfig = this.mSettingsModel.getGridConfig()
    let resultPositions: PositionLayoutInfo[][] = []
    this.setAllpositionsToNull(resultPositions)
    let tmpList: Array<string> = []
    let filterUniqueUsedPositions: Array<PositionLayoutInfo> = [...allPositions.flat()]
      .filter(item => item.typeId !== CommonConstants.INVALID_VALUE)// 去除空白
      .filter(item =>!tmpList.includes(item.keyName) && tmpList.push(item.keyName)) // 去重(folder, card占用多格场景只统计一格)
    let currentPosition: PositionLayoutInfo = undefined
    let hasLayout: boolean = false
    while (filterUniqueUsedPositions.length > 0) {
      currentPosition = filterUniqueUsedPositions[0]
      if (resultPositions[this.currentPointer.row][this.currentPointer.column].typeId !== CommonConstants.INVALID_VALUE) {
        //位置已被占用，指针后移
        this.updateTraversePointer()
      } else if (!this.canLayout(currentPosition, resultPositions)) {
        hasLayout = false
        // 位置不足以放置当前元素，查找下一个能够放置的元素
        for (let index = 1; index < filterUniqueUsedPositions.length; index++) {
          currentPosition = filterUniqueUsedPositions[index]
          if (this.canLayout(currentPosition, resultPositions)) {
            this.layout(currentPosition, resultPositions)
            filterUniqueUsedPositions.splice(index, 1)
            this.updateTraversePointer()
            hasLayout = true
            break
          }
        }

        if (!hasLayout) {
          // 当前位置不足以放下后续任何元素
          this.updateTraversePointer()
        }
      } else {
        // 位置足够放置当前元素
        this.layout(currentPosition, resultPositions)
        filterUniqueUsedPositions.splice(0, 1)
        this.updateTraversePointer()
      }
    }

    for (let i = 0; i < resultPositions.length; i++) {
      allPositions[i] = resultPositions[i]
    }
  }

  private layout(currentPosition: PositionLayoutInfo, resultPositions: PositionLayoutInfo[][]) {
    // 放置元素，更新位置信息
    for (let tmpRow = 0; tmpRow < currentPosition.area[1]; tmpRow++) {
      for (let tmpColumn = 0; tmpColumn < currentPosition.area[0]; tmpColumn++) {
        resultPositions[this.currentPointer.row + tmpRow][this.currentPointer.column + tmpColumn] = currentPosition
      }
    }
  }

  private canLayout(currentPosition: PositionLayoutInfo, resultPositions: PositionLayoutInfo[][]) {
    // 判断待放置元素所申请区域是否已被占用
    let canLayout: boolean = true
    for (let tmpRow = 0; tmpRow < currentPosition.area[1]; tmpRow++) {
      for (let tmpColumn = 0; tmpColumn < currentPosition.area[0]; tmpColumn++) {
        if (this.currentPointer.row + tmpRow >= this.mGridConfig.row
          || this.currentPointer.column + tmpColumn >= this.mGridConfig.column
          || resultPositions[this.currentPointer.row + tmpRow][this.currentPointer.column + tmpColumn].typeId !== CommonConstants.INVALID_VALUE) {
          canLayout = false
          break
        }
      }
    }
    return canLayout
  }

  private updateTraversePointer() {
    if (this.currentPointer.row < this.mGridConfig.row) {
      this.currentPointer.column++
      if (this.currentPointer.column >= this.mGridConfig.column) {
        this.currentPointer.column = 0
        this.currentPointer.row++
      }
    } else {
      this.currentPointer.row = this.mGridConfig.row
    }
  }
  //End zhuxiandi/n021839 <feat>  Wings功能回合桌面图标自动对其功能

  /**
   * get desktop's position info
   * @param destination
   * @param layoutInfo
   */
  private getAllPositions(destination, layoutInfo): any[] {
    Log.showDebug(TAG, 'getAllPositions start');
    const allPositions = [];
    this.setAllpositionsToNull(allPositions);

    // set position in layoutInfo to all positions
    for (let i = 0; i < layoutInfo.length; i++) {
      if (layoutInfo[i].page == destination.page) {
        if (layoutInfo[i].typeId == CommonConstants.TYPE_FOLDER || layoutInfo[i].typeId == CommonConstants.TYPE_CARD) {
          let keyName = '';
          if (layoutInfo[i].typeId == CommonConstants.TYPE_FOLDER) {
            keyName = layoutInfo[i].folderId;
          } else if (layoutInfo[i].typeId == CommonConstants.TYPE_CARD) {
            keyName = layoutInfo[i].cardId;
          }

          const positionInLayoutInfo = {
            typeId: layoutInfo[i].typeId,
            keyName: keyName,
            area: layoutInfo[i].area
          };
          for (let k = 0; k < layoutInfo[i].area[1]; k++) {
            for (let j = 0; j < layoutInfo[i].area[0]; j++) {
              allPositions[layoutInfo[i].row + k][layoutInfo[i].column + j] = positionInLayoutInfo;
            }
          }
        } else if (layoutInfo[i].typeId == CommonConstants.TYPE_APP) {
          const positionInLayoutInfo = {
            typeId: layoutInfo[i].typeId,
            keyName: layoutInfo[i].keyName,
            area: layoutInfo[i].area
          };
          allPositions[layoutInfo[i].row][layoutInfo[i].column] = positionInLayoutInfo;
        }
      }
    }
    return allPositions;
  }

  private setAllpositionsToNull(allPositions): void {
    const mGridConfig = this.mSettingsModel.getGridConfig();
    const pageRow = mGridConfig.row;
    const pageColumn = mGridConfig.column;

    // set null to all positions in current page
    for (let row = 0; row < pageRow; row++) {
      const rowPositions = [];
      for (let column = 0; column < pageColumn; column++) {
        const position = {
          typeId: -1,
          keyName: 'null',
          area: []
        };
        rowPositions.push(position);
      }
      allPositions.push(rowPositions);
    }
  }

  /**
   * get desktop's position count by Object
   * @param destination
   * @param layoutInfo
   */
  private getObjectPositionCount(destination, layoutInfo): Map<string, number> {
    Log.showDebug(TAG, 'getObjectPositionCount start');

    const objectPositionCount = new Map<string, number>();
    // set position in layoutInfo to all positions
    for (let i = 0; i < layoutInfo.length; i++) {
      if (layoutInfo[i].page == destination.page) {
        const count = layoutInfo[i].area[0] * layoutInfo[i].area[1];
        let keyName = '';
        if (layoutInfo[i].typeId == CommonConstants.TYPE_FOLDER) {
          keyName = layoutInfo[i].folderId;
        } else if (layoutInfo[i].typeId == CommonConstants.TYPE_CARD) {
          keyName = layoutInfo[i].cardId;
        } else if (layoutInfo[i].typeId == CommonConstants.TYPE_APP) {
          keyName = layoutInfo[i].keyName;
        }
        objectPositionCount.set(keyName, count);
      }
    }
    return objectPositionCount;
  }

  /**
   * get Object under pressed big folder or form
   * @param destination
   * @param allPositions
   * @param dragItemInfo
   */
  private getPressedObjects(destination, allPositions, dragItemInfo: LauncherDragItemInfo): {
    apps: Array<LauncherDragItemInfo>,
    foldersAndForms: Array<LauncherDragItemInfo>
  } {
    Log.showDebug(TAG, 'getPressedObjects start');
    const row = destination.row;
    const column = destination.column;
    const apps = [];
    const foldersAndForms = [];

    Log.showDebug(TAG, `getPressedObjects destination.row: ${row},destination.column:${column}`);

    for (let j = 0; j < dragItemInfo.area[1]; j++) {
      for (let i = 0; i < dragItemInfo.area[0]; i++) {
        if (allPositions[row + j][column + i].typeId == CommonConstants.TYPE_APP) {
          apps.push(allPositions[row + j][column + i]);
        } else if (allPositions[row + j][column + i].typeId == CommonConstants.TYPE_FOLDER &&
        allPositions[row + j][column + i].keyName != dragItemInfo.folderId) {
          foldersAndForms.push(allPositions[row + j][column + i]);
        } else if (allPositions[row + j][column + i].typeId == CommonConstants.TYPE_CARD &&
        allPositions[row + j][column + i].keyName != dragItemInfo.cardId) {
          foldersAndForms.push(allPositions[row + j][column + i]);
        }
      }
    }

    Log.showDebug(TAG, `getPressedObjects foldersAndForms.length: ${foldersAndForms.length}`);
    Log.showDebug(TAG, `getPressedObjects apps.length: ${apps.length}`);
    const pressedObjects = {
      apps,
      foldersAndForms
    };
    return pressedObjects;
  }

  /**
   * check of canMove in same page
   * @param pressedPositions
   * @param objectPositionCount
   * @param dragItemInfo
   */
  private checkCanMoveInSamePage(pressedPositions, objectPositionCount, dragItemInfo: LauncherDragItemInfo): boolean {
    Log.showDebug(TAG, 'checkCanMoveInSamePage start');
    const foldersAndForms = pressedPositions.foldersAndForms;
    if (foldersAndForms.length == 0) {
      return true;
    }

    if (foldersAndForms.length == 1) {
      if (dragItemInfo.typeId == CommonConstants.TYPE_APP && foldersAndForms[0].typeId == CommonConstants.TYPE_CARD) {
        return true;
      }
    }

    const coverPositionCount = new Map<string, number>();
    Log.showDebug(TAG, `checkCanMoveInSamePage foldersAndForms.length: ${foldersAndForms.length}`);
    for (let i = 0; i < foldersAndForms.length; i++) {
      const keyName = foldersAndForms[i].keyName;
      if (coverPositionCount.has(keyName)) {
        coverPositionCount.set(keyName, coverPositionCount.get(keyName) + 1);
      } else {
        coverPositionCount.set(keyName, 1);
      }
    }

    for (const keyName of coverPositionCount.keys()) {
      if (coverPositionCount.get(keyName) < objectPositionCount.get(keyName) / 2) {
        Log.showDebug(TAG, 'checkCanMoveInSamePage end false');
        return false;
      }
    }
    return true;
  }

  /**
   * check of canMove in diff page
   * @param allPositions
   */
  private checkCanMoveInDiffPage(allPositions, dragItemInfo): boolean {
    Log.showDebug(TAG, 'checkCanMoveInDiffPage start');
    let count = 0;
    for (let i = 0; i < allPositions.length; i++) {
      for (let j = 0; j < allPositions[i].length; j++) {
        if (allPositions[i][j].typeId == -1) {
          count++;
        }
      }
    }
    const minCount = dragItemInfo.area[0] * dragItemInfo.area[1];
    // target page empty position min is dragItemInfo's need position
    if (count < minCount) {
      Log.showDebug(TAG, 'checkCanMoveInDiffPage end false');
      return false;
    }
    return true;
  }

  /**
   * set source‘s position to null
   * @param source
   * @param allPositions
   */
  private setSourcePositionToNull(dragItemInfo, allPositions): void {
    Log.showDebug(TAG, 'setSourcePositionToNull start');
    for (let j = 0; j < dragItemInfo.area[1]; j++) {
      for (let i = 0; i < dragItemInfo.area[0]; i++) {
        const nullPosition = {
          typeId: -1,
          keyName: 'null',
          area: []
        };
        allPositions[dragItemInfo.row + j][dragItemInfo.column + i] = nullPosition;
      }
    }
  }

  /**
   * set direction‘s position to null
   * @param destination
   * @param allPositions
   * @param dragItemInfo
   */
  private setDestinationPosition(destination, allPositions, dragItemInfo): void {
    Log.showDebug(TAG, 'setDestinationPosition start');
    let keyName = '';
    if (dragItemInfo.typeId == CommonConstants.TYPE_FOLDER) {
      keyName = dragItemInfo.folderId;
    } else if (dragItemInfo.typeId == CommonConstants.TYPE_CARD) {
      keyName = dragItemInfo.cardId;
    } else if (dragItemInfo.typeId == CommonConstants.TYPE_APP) {
      keyName = dragItemInfo.keyName;
    }

    for (let j = 0; j < dragItemInfo.area[1]; j++) {
      for (let i = 0; i < dragItemInfo.area[0]; i++) {
        if (allPositions[destination.row + j][destination.column+ i].typeId == -1) {
          const destinationPosition = {
            typeId: dragItemInfo.typeId,
            keyName: keyName,
            area: dragItemInfo.area
          };
          allPositions[destination.row + j][destination.column+ i] = destinationPosition;
        }
      }
    }
  }

  /**
   * move folders and forms to target position
   * @param foldersAndForms
   * @param destination
   * @param allPositions
   * @param dragItemInfo
   */
  private moveFoldersAndForms(foldersAndForms, destination, allPositions, dragItemInfo: LauncherDragItemInfo): boolean {
    Log.showDebug(TAG, 'moveFoldersAndForms start');
    const movedFoldersAndForms = [];
    for (let i = 0; i < foldersAndForms.length; i++) {
      const moveFolderOrForm = foldersAndForms[i];
      if (movedFoldersAndForms.indexOf(moveFolderOrForm.keyName) != -1) {
        continue;
      }

      for (let row = 0; row < allPositions.length; row++) {
        for (let column = 0; column < allPositions[row].length; column++) {
          if (moveFolderOrForm.keyName == allPositions[row][column].keyName) {
            this.updateDestinationToNull(dragItemInfo, destination, allPositions, row, column);
          }
        }
      }

      let isUsablePosition = false;
      for (let row = 0; row < allPositions.length; row++) {
        if (isUsablePosition) {
          break;
        }
        for (let column = 0; column < allPositions[row].length; column++) {
          const usablePositionCount =this.getUsablePositionCount(moveFolderOrForm, allPositions, row , column);
          if (usablePositionCount == moveFolderOrForm.area[1] * moveFolderOrForm.area[0]) {
            isUsablePosition = true;
            this.updatePositionByMoveItem(moveFolderOrForm, allPositions, row, column);
            movedFoldersAndForms.push(moveFolderOrForm.keyName);
            break;
          }
        }
      }
      if (!isUsablePosition) {
        Log.showDebug(TAG, 'moveFoldersAndForms return false');
        return false;
      }
    }
    this.updateDestinationByDragItem(dragItemInfo, destination, allPositions);
    return true;
  }

  /**
   * get the count of usable position
   * @param moveFolderOrForm
   * @param allPositions
   * @param row
   * @param column
   */
  private getUsablePositionCount(moveFolderOrForm, allPositions, row , column): number {
    let getUsablePositionCount = 0;
    for (let j = 0; j < moveFolderOrForm.area[1]; j++) {
      for (let i = 0; i < moveFolderOrForm.area[0]; i++) {
        if (row + j < allPositions.length && column + i < allPositions[row].length && allPositions[row + j][column + i].typeId == -1) {
          getUsablePositionCount++;
        }
      }
    }
    return getUsablePositionCount;
  }

  /**
   * update destination to nullPosition
   *
   * @param dragItemInfo
   * @param destination
   * @param allPositions
   * @param row
   * @param column
   */
  private updateDestinationToNull(dragItemInfo: LauncherDragItemInfo, destination, allPositions, row, column): void {
    let destinationFlag = false;
    for (let j = 0; j < dragItemInfo.area[1]; j++) {
      if (destinationFlag) {
        break;
      }
      for (let i = 0; i < dragItemInfo.area[0]; i++) {
        if (destination.row + j == row && destination.column + i == column) {
          destinationFlag = true;
          break;
        }
      }
    }
    if (!destinationFlag) {
      const nullPosition = {
        typeId: -1,
        keyName: 'null',
        area: []
      };
      allPositions[row][column] = nullPosition;
    }
  }

  /**
   * update destination position by dragItemInfo
   *
   * @param dragItemInfo
   * @param destination
   * @param allPositions
   */
  private updateDestinationByDragItem(dragItemInfo: LauncherDragItemInfo, destination, allPositions): void {
    let keyName = '';
    if (dragItemInfo.typeId == CommonConstants.TYPE_FOLDER) {
      keyName = dragItemInfo.folderId;
    } else if (dragItemInfo.typeId == CommonConstants.TYPE_CARD) {
      keyName = dragItemInfo.cardId >= 0 ? String(dragItemInfo.cardId) : '';
    } else if (dragItemInfo.typeId == CommonConstants.TYPE_APP) {
      keyName = dragItemInfo.keyName;
    }

    for (let j = 0; j < dragItemInfo.area[1]; j++) {
      for (let i = 0; i < dragItemInfo.area[0]; i++) {
        const dragItemPosition = {
          typeId: dragItemInfo.typeId,
          keyName: keyName,
          area: dragItemInfo.area
        };
        allPositions[destination.row + j][destination.column + i] = dragItemPosition;
      }
    }
  }

  /**
   * update positions by moveItemInfo
   *
   * @param moveFolderOrForm
   * @param allPositions
   * @param row
   * @param column
   */
  private updatePositionByMoveItem(moveFolderOrForm, allPositions, row, column): void {
    for (let j = 0; j < moveFolderOrForm.area[1]; j++) {
      for (let i = 0; i < moveFolderOrForm.area[0]; i++) {
        const movePosition = {
          typeId: moveFolderOrForm.typeId,
          keyName: moveFolderOrForm.keyName,
          area: moveFolderOrForm.area
        };
        allPositions[row + j][column + i] = movePosition;
      }
    }
  }

  /**
   * move apps to target position
   * @param apps
   * @param allPositions
   */
  private moveApps(apps, allPositions): void {
    Log.showDebug(TAG, 'moveApps start');
    for (let i = 0; i < apps.length; i++) {
      const app = apps[i];
      let isUsable = false;
      for (let row = 0; row < allPositions.length; row++) {
        if (isUsable) {
          break;
        }
        for (let column = 0; column < allPositions[row].length; column++) {
          if (allPositions[row][column].typeId == -1) {
            const appPosition = {
              typeId: app.typeId,
              keyName: app.keyName,
              area: app.area
            };
            allPositions[row][column] = appPosition;
            isUsable = true;
            break;
          }
        }
      }
    }
  }
}
