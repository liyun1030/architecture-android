先运行：
start_log_save.bat   ==>开始保存日志设备 刷机后只需执行一次
重启后，连网

hdc file recv /data/log .

gethilog.bat   ==》抓到所有日志
生成的日志log.tar.gz发给开发分析

0.4
添加死机场景下抓取kernel和进程日志

0.5
生成日志根据目录，自动解压缩log.tar.gz