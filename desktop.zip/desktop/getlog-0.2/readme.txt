start_log_save.bat   ==>开始保存日志设备 刷机后只需执行一次
gethilog.bat   ==》抓到所有日志
生成的日志log.tar.gz发给开发分析


hdc file recv /data/bluetooth/log/snoop.log snoop.log