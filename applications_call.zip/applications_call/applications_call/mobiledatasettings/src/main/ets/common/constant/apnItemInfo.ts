@Observed
export class ApnItemInfo{
  id: string
  key: Resource
  value: string | number
}