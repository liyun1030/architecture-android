/**
 * Copyright (c) 2025 Archermind Technology(Nanjing) CO., LTD.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */


import dataShare from '@ohos.data.dataShare';
import Context from 'application/ServiceExtensionContext';
import createOrGet from './SingleInstanceHelper';
import LogUtils from '../../common/utils/LogUtils';
import telephonyData from '@ohos.telephony.data';

const TAG = 'DataStatusVM';
var mDataStatus = AppStorage.setAndLink('DataStatus', false);

export class DataStatusVM {
  helper: dataShare.DataShareHelper;
  uri: string;
  context: Context;
  mIsStart = false;
  constructor() {
    this.uri = this.getUriSync('cellular_data_enable');
    this.context = globalThis.settingsAbilityContext;
    this.init();
    LogUtils.d(TAG, 'constructor');
  }

  getUriSync(key: string): string {
    return "datashare:///com.ohos.settingsdata/entry/settingsdata/SETTINGSDATA?Proxy=true&key=" + key;
  }
  async init(): Promise<void> {
    LogUtils.i(TAG, 'init');
    this.helper = await dataShare.createDataShareHelper(this.context, this.uri);
    LogUtils.i(TAG, `init helper ${this.helper}`);
    this.registerDataStatus();
  }

  registerDataStatus() {
    this.helper.on("dataChange", this.uri, () => {
      LogUtils.i(TAG, `OneFan register datastatus helper dataChange`);
      this.getStatus()
    })
  }

  getStatus() {
    this.isCellularDataEnabled().then((data) => {
      LogUtils.i(TAG, "isCellularDataEnabled success: isON1:" + JSON.stringify(data));
      mDataStatus.set(data);
      LogUtils.i(TAG, "mDataStatus get:" + mDataStatus.get());
    }).catch((error) => {
      LogUtils.i(TAG, "isCellularDataEnabled error catch" + JSON.stringify(error));
    });
  }

  isCellularDataEnabled() {
    return telephonyData.isCellularDataEnabled();
  }

  unRegisterDataFlow() {
    this.helper?.off("dataChange", this.uri, (err) => {
      LogUtils.i(TAG, `unregister DataStatus helper`);
    })
  }
}

let sDataStatusVM = createOrGet(DataStatusVM, TAG);

export default sDataStatusVM;