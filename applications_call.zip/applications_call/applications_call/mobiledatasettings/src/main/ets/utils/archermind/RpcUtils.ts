/**
 * Copyright (c) 2025 Archermind Technology(Nanjing) CO., LTD.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
import rpc from '@ohos.rpc';
import common from '@ohos.app.ability.common';
import process from '@ohos.process';
import bundleManager from '@ohos.bundle.bundleManager';

import { BiInfo, BiServiceEventIdEnums, BiConstant, BiInfoContext } from '@ohos/common/src/main/ets/constants/BiConstant';
import hilog from '@ohos.hilog';
import { BusinessError } from '@ohos.base';
import { Options } from 'archermind';

const TAG = "rpc_utils";

//Begin Liyun/n034240 新增RpcUtils工具类 20250427 Add
let biInfo: BiInfo = {
  biEventId: BiServiceEventIdEnums.Default,
  context: {}
}
let lastEnterTime = 0;
let num = 0;

export const connectOption: common.ConnectOptions = {
  onConnect(elementName, remote) {
    hilog.info(0x0000,TAG, `connectOption onConnect element: ${JSON.stringify(elementName)}; remote: ${JSON.stringify(remote.getDescriptor())}`);
    let option = new rpc.MessageOption();
    let data = rpc.MessageSequence.create();
    let reply = rpc.MessageSequence.create();
    let commRemote: rpc.IRemoteObject | null;
    data.writeStringArray([
      JSON.stringify({
        progress: "com.ohos.callui",
      }),
      JSON.stringify(biInfo)
    ]);

    // for debug
    // const array: Array<string> = new Array(2);
    // data.readStringArray(array);
    // const baseInfo = JSON.parse(array[0]) as object;
    // const biInfomation = JSON.parse(array[1]) as BiInfo;
    // console.info(`${TAG}, ${typeof baseInfo} ${(biInfomation)}`);
    remote.sendMessageRequest(1, data, reply, option).then((result: rpc.RequestResult)=>{
      if (result.errCode === 0) {
        hilog.info(0x0000, TAG, 'sendMessageRequest got result');
        try {
          result.reply.readException();
        } catch (error) {
          let e: BusinessError = error as BusinessError;
          hilog.error(0x0000, TAG, 'rpc read exception fail, errorCode ' + e.code);
          hilog.error(0x0000, TAG, 'rpc read exception fail, errorMessage ' + e.message);
        }
        let num = result.reply.readInt();
        hilog.info(0x0000, TAG, 'RPCTest: reply num: ' + num);
      } else {
        hilog.error(0x0000, TAG, 'RPCTest: sendMessageRequest failed, errCode: ' + result.errCode);
      }
    }).catch((e: Error) => {
      hilog.error(0x0000, TAG, 'RPCTest: sendMessageRequest got exception: ' + e.message);
    }).finally (() => {
      hilog.info(0x0000, TAG, 'RPCTest: sendMessageRequest ends, reclaim parcel');
      data.reclaim();
      reply.reclaim();
      //关闭连接
      let context = globalThis.settingsAbilityContext ? globalThis.settingsAbilityContext : globalThis.calluiAbilityContext;
      console.log('disconnectServiceExtensionAbility num :'+num);
      try {
        context.disconnectServiceExtensionAbility(num).then(() => {
          commRemote = null;
          console.log('disconnectServiceExtensionAbility succeed');
        }).catch((err: BusinessError) => {
          console.error(`disconnectServiceExtensionAbility failed, code is ${err.code}, message is ${err.message}`);
        })
      } catch (err) {
        commRemote = null;
        // 处理入参错误异常
        let code = (err as BusinessError).code;
        let message = (err as BusinessError).message;
        console.error(`disconnectServiceExtensionAbility failed, code is ${code}, message is ${message}`);
      }
    });
  },
  onDisconnect(elementName) {
    hilog.info(0x0000,TAG, `connectOption onDisconnect element: ${JSON.stringify(elementName)}`);
  },
  onFailed(code) {
    hilog.info(0x0000,TAG, `connectOption onFailed code: ${JSON.stringify(code)}`);
  }
}

export default function sendRpcMessage(operationType: BiServiceEventIdEnums, biInfoContext?: BiInfoContext) {
  if(!Options.isShowCellularData()) {
    return;
  }
  let context = globalThis.settingsAbilityContext ? globalThis.settingsAbilityContext : globalThis.calluiAbilityContext;
  console.log(TAG, `sendRpcMessage, operationType is => ${operationType}, BiInfoContext => ${JSON.stringify(biInfoContext)}`);
  if (!context || operationType === BiServiceEventIdEnums.Default) {
    console.log(TAG, `sendRpcMessage, params is invalid! `);
    return;
  }
  biInfo.biEventId = operationType;
  switch (operationType) {
    case BiServiceEventIdEnums.AppUsageTime:
      getAppUsageTime();
      break;
    case BiServiceEventIdEnums.AppInstallation:
      getAppInstallation();
      break;
    case BiServiceEventIdEnums.AppUnInstallation:
      getAppUninstallation();
      break;
    case BiServiceEventIdEnums.WifiOperations:
      setWifiOperation(biInfoContext.value);
      break;
    case BiServiceEventIdEnums.BtOperations:
      setBluetoothOperation(biInfoContext.value);
      break;
    case BiServiceEventIdEnums.DataOperations:
      setMobileDataOperation(biInfoContext.value);
      break;
    case BiServiceEventIdEnums.LocationOperations:
      setLocationOperation(biInfoContext.value);
      break;
    case BiServiceEventIdEnums.OtaUpgrades:
      setOtaInstallation(biInfoContext.value);
      break;
    case BiServiceEventIdEnums.Call:
      setPhoneCall(biInfoContext);
      break;
    case BiServiceEventIdEnums.SimActive:
      setSimActive(biInfoContext.carrierInfo);
      break;
    default:
      console.log(TAG, `unknown operationType, ignore it`);
      break;
  }

  num = context.connectServiceExtensionAbility({
    abilityName: BiConstant.BI_ABILITY_NAME,
    bundleName: BiConstant.BI_BOUND_NAME,
  }, connectOption);

  console.info(TAG, `sendRpcMessage num: ${num}`);

  // context.disconnectServiceExtensionAbility(num).then((res) => {
  //   console.log(`sendRpcMessage, disconnectServiceExtensionAbility:  ${JSON.stringify(res)}`);
  // });
}


// =========== 1001 - 1003 ================

export function getBoundName() {
  try {
    const data = bundleManager.getBundleInfoForSelfSync(bundleManager.BundleFlag.GET_BUNDLE_INFO_DEFAULT)
    console.log(`${TAG}: getBoundName successfully ${JSON.stringify(data)}}`);
    return data.name;
  } catch (e) {
    console.error(TAG, `e is => ${JSON.stringify(e)}`);
    return "";
  }
}

// 进入系统后台时调用【enter时调用】
export  function getAppEnterTime() {
  lastEnterTime = process.uptime();
}

// 应用退出时调用
export function getAppTotalUsageTime() {
  return process.uptime() - lastEnterTime;
}

export function getAppUsageTime() {
  biInfo = {
    biEventId: BiServiceEventIdEnums.AppUsageTime,
    context: {
      appName: getBoundName(),
      appUsageTime: getAppTotalUsageTime().toString()
    }
  }
}

// 监听应用安装
export function getAppInstallation() {
  biInfo = {
    biEventId: BiServiceEventIdEnums.AppInstallation,
    context: {
      appName: getBoundName(),
    }
  }
}

export function getAppUninstallation() {
  biInfo = {
    biEventId: BiServiceEventIdEnums.AppUnInstallation,
    context: {
      appName: getBoundName()
    }
  }
}

// ============ 2001 - 2003 ================
// settings 模块 和 systemui 模块都要添加

function setWifiOperation(value: number) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.WifiOperations,
    context: {
      value: value
    }
  }
}

function setBluetoothOperation(value: number) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.BtOperations,
    context: {
      value: value
    }
  }
}

function setMobileDataOperation(value: number) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.DataOperations,
    context: {
      value: value
    }
  }
}

function setLocationOperation(value: number) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.LocationOperations,
    context: {
      value: value
    }
  }
}

// ============ 3001 - 3002 ==========
// OTA 升级
// 搜包结果 CheckResult

// com.ohos.updateapp
function setOtaInstallation(value: number) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.OtaUpgrades,
    context: {
      value: value
    }
  }
}
// ============= 4001 —— 4002 =============
function setPhoneCall(biInfoContext: BiInfoContext) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.Call,
    context: {
      ...biInfoContext
    }
  }
}

/**
 * sim 卡激活，
 * @param carrier 运营商名称
 */
function setSimActive(carrier: string) {
  biInfo = {
    biEventId: BiServiceEventIdEnums.SimActive,
    context: {
      carrierInfo: carrier
    }
  }
}
//End Liyun/n034240 新增RpcUtils工具类 20250427 Add