/**
 * Copyright (c) 2025 Archermind Technology(Nanjing) CO., LTD.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//Begin Liyun/n034240 新增BiConstant常量类 20250427 Add
export class BiConstant {
  static STUB_NAME = "BI_ServiceAbility";

  static readonly BI_ABILITY_NAME = "ServiceAbility";
  static readonly BI_BOUND_NAME = "com.laval.bi";

  static readonly DEFAULT_CALL_DURATION = 0;

  static readonly CONST_BI_WU_KONG_MODE = "const.bi.wukong.mode";
  static readonly PERSIST_BASIC_BI_URL = "persist.basic.bi.url";
}

export enum BiServiceEventIdEnums {
  Default = 0,

  AppUsageTime = 1001,
  AppInstallation = 1002,
  AppUnInstallation = 1003,

  WifiOperations = 2001,
  BtOperations = 2002,
  DataOperations = 2003,
  LocationOperations = 2004,

  OtaUpgrades = 3001, // 立刻上报

  Call = 4001,
  SimActive = 4002,

  AI = 5001 // 小瓦 AI
}

export interface BiInfo {
  biEventId: BiServiceEventIdEnums,
  context: {[key: string]: any},
  progress?: string, // app bundleName
}

export interface BiInfoContext {
  // 1001 - 1003
  appName?: string,
  // 1001
  appUsageTime?: string,
  // 2001 - 2004
  value?: number,

  // 3001
  searchPackageResult?: number, // 搜包检验结果： 0 成功，1 失败
  installationResult?: number,  // 安装结果： 0 成功， 1 失败
  isManualSearchPackage?: number, // 是否手动搜包： 0 不是， 1 是
  isGrayScale?: number, // 是否灰度： 0 不是， 1 是
  originSysVersion?: string,  // 源版本
  targetSysVersion?: string;  // 目标

  // call 4001
  isCalling?: number, // 0 主叫， 1 被叫
  phoneCallConnected?: number,  // 电话是否接通
  callDuration?: number,

  // carrier info 4002
  carrierInfo?: string;

  // 5001, AI
  questionId?: string,
  isUseful?: string,
  questionDescription?: string,
  time?: string,
  deviceType?: string,
  aiVersion?: string
}

export interface BiLog {
  duid: string, // 设备 ID
  productModel: string,
  sysVersion: string,
  networkType: NetworkTypeEnums
  data: Array<BiInfo>, // BiInfo
}

export enum NetworkTypeEnums {
  Wifi = "00",
  MobileData = "10",
  Both = "11",
  None = ""
}

export enum SwitchOperationEnums {
  OPEN = 1,
  CLOSE = 0
}

export enum CallingType {
  CALLING = 0,
  CALLED = 1,
}

export enum PhoneCallConnected {
  NOT_CONNECTED = 0,
  CONNECTED = 1
}

export enum SoundType {
  EARPIECE = 0,
  SPEAKER = 1,
  BT_HEADPHONE = 2
}
//End Liyun/n034240 新增BiConstant常量类 20250427 Add