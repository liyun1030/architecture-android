export class IRequest {
    get msg() {
        return this._msg;
    }
    get data() {
        return this._data;
    }
    constructor(msg) {
        this._msg = msg;
        this._data = [];
    }
    makeParam(...args) {
        for (let b2 = 0; b2 < args.length; b2++) {
            this._data.push(JSON.stringify(args[b2]));
        }
    }
    marshalling(dataOut) {
        dataOut.writeString(this._msg);
        dataOut.writeStringArray(this._data);
        return true;
    }
    unmarshalling(dataIn) {
        this._msg = dataIn.readString();
        this._data = dataIn.readStringArray();
        return true;
    }
}
