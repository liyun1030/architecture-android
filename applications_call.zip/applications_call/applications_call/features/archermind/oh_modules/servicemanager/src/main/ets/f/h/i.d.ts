import rpc from '@ohos.rpc';
export declare class IRequest implements rpc.Parcelable {
    _msg: string;
    _data: string[];
    get msg(): string;
    get data(): string[];
    constructor(msg: string);
    makeParam(...args: ESObject): void;
    marshalling(dataOut: rpc.MessageSequence): boolean;
    unmarshalling(dataIn: rpc.MessageSequence): boolean;
}
