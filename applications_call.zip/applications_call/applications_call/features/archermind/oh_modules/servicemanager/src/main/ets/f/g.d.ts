import { processDataCallback } from "./k";
import { processByteCallback } from "./k";
import IBaseServiceExt from "./k";
import { IRequest } from "./h/i";
import { IByteRequest } from "./h/j";
export default class BaseServiceExtProxy implements IBaseServiceExt {
    constructor(proxy: any);
    processData(data: IRequest, callback: processDataCallback): void;
    processByte(j1: IByteRequest, callback: processByteCallback): void;
    static readonly COMMAND_PROCESS_DATA = 1;
    static readonly COMMAND_PROCESS_BYTE = 2;
    private proxy;
}
