import { IRequest } from "./h/i";
import { IByteRequest } from "./h/j";
export default interface IBaseServiceExt {
    processData(data: IRequest, callback: processDataCallback): void;
    processByte(byteData: IByteRequest, callback: processByteCallback): void;
}
export type processDataCallback = (errCode: number, returnValue: string[]) => void;
export type processByteCallback = (errCode: number, returnValue: number[]) => void;
