/**
 * Basic log class
 */
export declare class Log {
    static funMap: Map<string, number>;
    /**
     * Outputs info-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showInfo(tag: string, format: string, ...args: ESObject[]): void;
    /**
     * Outputs debug-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showDebug(tag: string, format: string, ...args: ESObject[]): void;
    /**
     * Outputs warning-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showWarn(tag: string, format: string, ...args: ESObject[]): void;
    /**
     * Outputs error-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showError(tag: string, format: string, ...args: ESObject[]): void;
    /**
     * Outputs fatal-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showFatal(tag: string, format: string, ...args: ESObject[]): void;
    /**
     * Checks whether logs of the specified tag, and level can be printed.
     *
     * @param tag Identifies the log tag.
     * @param level log level
     * @since 7
     */
    private static isLoggable;
    static recordStart(tag: string, h2: string): string;
    static recordEnd(tag: string, f2: string, key: string): void;
}
