import hilog from '@ohos.hilog';
import { BUILD_MODE_NAME, HAR_VERSION } from "../../../../a";
const DOMAIN = 0x001f;
const i = `Wings-ServiceManager(${HAR_VERSION}-${BUILD_MODE_NAME})`;
const e2 = " --> ";
export class Log {
    static showInfo(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.INFO)) {
            hilog.info(DOMAIN, i, tag + e2 + format, args);
        }
    }
    static showDebug(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.DEBUG)) {
            hilog.debug(DOMAIN, i, tag + e2 + format, args);
        }
    }
    static showWarn(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.WARN)) {
            hilog.warn(DOMAIN, i, tag + e2 + format, args);
        }
    }
    static showError(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.ERROR)) {
            hilog.error(DOMAIN, i, tag + e2 + format, args);
        }
    }
    static showFatal(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.FATAL)) {
            hilog.fatal(DOMAIN, i, tag + e2 + format, args);
        }
    }
    static isLoggable(tag, level) {
        return hilog.isLoggable(DOMAIN, tag, level);
    }
    static recordStart(tag, h2) {
        let key = `${tag}-${h2}-${Math.floor(Math.random() * 100)}`;
        if (Log.isLoggable(tag, hilog.LogLevel.DEBUG)) {
            hilog.debug(DOMAIN, i, 'Function Follow:' + tag + '.' + h2 + '=>Function Start');
            let time = Date.now();
            Log.funMap.set(key, time);
        }
        return key;
    }
    static recordEnd(tag, f2, key) {
        let startTime;
        if (Log.isLoggable(tag, hilog.LogLevel.DEBUG)) {
            if (Log.funMap.has(key)) {
                startTime = Log.funMap.get(key);
            }
            else {
                hilog.debug(DOMAIN, i, 'Function Follow:' + tag + '.' + f2 + '=>Function End (not record Start)');
                return;
            }
            let g2 = Date.now();
            hilog.debug(DOMAIN, i, 'Function Follow:' + tag + '.' + f2 + `=>Function End (${g2 - startTime}ms)`);
            Log.funMap.delete(key);
        }
    }
}
Log.funMap = new Map();
