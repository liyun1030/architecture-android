export declare class ArrayBufferUtils {
    static byte2ArrayBuffer(data: Array<number>): ArrayBuffer;
    static arrayBuffer2Byte(buf: ArrayBuffer): Array<number>;
}
