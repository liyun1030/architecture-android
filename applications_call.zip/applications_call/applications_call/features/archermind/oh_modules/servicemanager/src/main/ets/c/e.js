export class ArrayBufferUtils {
    static byte2ArrayBuffer(data) {
        let d2 = new Uint8Array(data);
        return d2.buffer;
    }
    static arrayBuffer2Byte(buf) {
        let arr = new Uint8Array(buf);
        let result = [];
        for (let c2 = 0; c2 < arr.length; c2++) {
            result.push(arr[c2]);
        }
        return result;
    }
}
