export class IByteRequest {
    get msg() {
        return this._msg;
    }
    get data() {
        return this._data;
    }
    constructor(msg) {
        this._msg = msg;
        this._data = [];
    }
    setParam(data) {
        this._data = data.slice(0);
    }
    marshalling(dataOut) {
        dataOut.writeString(this._msg);
        dataOut.writeByteArray(this._data);
        return true;
    }
    unmarshalling(dataIn) {
        this._msg = dataIn.readString();
        this._data = dataIn.readByteArray();
        return true;
    }
}
