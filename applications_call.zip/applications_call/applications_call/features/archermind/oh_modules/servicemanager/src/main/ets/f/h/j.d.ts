import rpc from '@ohos.rpc';
export declare class IByteRequest implements rpc.Parcelable {
    _msg: string;
    _data: number[];
    get msg(): string;
    get data(): number[];
    constructor(msg: string);
    setParam(data: number[]): void;
    marshalling(dataOut: rpc.MessageSequence): boolean;
    unmarshalling(dataIn: rpc.MessageSequence): boolean;
}
