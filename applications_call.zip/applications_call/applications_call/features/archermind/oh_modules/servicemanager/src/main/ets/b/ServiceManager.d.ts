import common from '@ohos.app.ability.common';
import BaseServiceExtProxy from "../f/g";
declare class j {
    static instance: j;
    constructor();
    static getInstance(): j;
    m(context: common.UIAbilityContext, h1: (service: BaseServiceExtProxy) => void): number;
    o(context: common.UIAbilityContext, g1: number): void;
    /**
     callback: code:-10001 服务创建失败|
     *         code:0      调用成功|
     *         code:1      参数错误|
     *         code:2      消息未实现|
     */
    processNormal(context: common.UIAbilityContext, callback: (code: number, result: string[]) => void, msg: string, ...args: ESObject): void;
    /**
     callback: code:-10001 服务创建失败|
     *         code:0      调用成功|
     *         code:1      参数错误|
     *         code:2      消息未实现|
     */
    processByte(context: common.UIAbilityContext, callback: (code: number, result: ArrayBuffer) => void, msg: string, buffer: ArrayBuffer): void;
}
export declare const ServiceManager: j;
export declare function processNormal(context: common.UIAbilityContext, callback: (code: number, result: string[]) => void, msg: string, ...args: ESObject): void;
export declare function processByte(context: common.UIAbilityContext, callback: (code: number, result: ArrayBuffer) => void, msg: string, buffer: ArrayBuffer): void;
export {};
