import rpc from "@ohos.rpc";
export default class BaseServiceExtProxy {
    constructor(proxy) {
        this.proxy = proxy;
    }
    processData(data, callback) {
        let s1 = new rpc.MessageOption();
        let t1 = new rpc.MessageSequence();
        let u1 = new rpc.MessageSequence();
        t1.writeParcelable(data);
        this.proxy.sendMessageRequest(BaseServiceExtProxy.COMMAND_PROCESS_DATA, t1, u1, s1).then(function (result) {
            if (result.errCode === 0) {
                let w1 = result.reply.readInt();
                if (w1 != 0) {
                    let a2 = undefined;
                    callback(w1, a2);
                    return;
                }
                let z1 = result.reply.readStringArray();
                callback(w1, z1);
            }
            else {
                console.log("sendMessageRequest failed, errCode: " + result.errCode);
            }
        });
    }
    processByte(j1, callback) {
        let k1 = new rpc.MessageOption();
        let l1 = new rpc.MessageSequence();
        let m1 = new rpc.MessageSequence();
        l1.writeParcelable(j1);
        this.proxy.sendMessageRequest(BaseServiceExtProxy.COMMAND_PROCESS_BYTE, l1, m1, k1).then(function (result) {
            if (result.errCode === 0) {
                let o1 = result.reply.readInt();
                if (o1 != 0) {
                    let q1 = undefined;
                    callback(o1, q1);
                    return;
                }
                let p1 = result.reply.readByteArray();
                callback(o1, p1);
            }
            else {
                console.log("sendMessageRequest failed, errCode: " + result.errCode);
            }
        });
    }
}
BaseServiceExtProxy.COMMAND_PROCESS_DATA = 1;
BaseServiceExtProxy.COMMAND_PROCESS_BYTE = 2;
