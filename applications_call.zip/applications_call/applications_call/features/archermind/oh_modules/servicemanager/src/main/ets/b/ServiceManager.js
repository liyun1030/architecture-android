import { Log } from "../c/d";
import { ArrayBufferUtils } from "../c/e";
import BaseServiceExtProxy from "../f/g";
import { IRequest } from "../f/h/i";
import { IByteRequest } from "../f/h/j";
const i = 'ServiceManager';
const want = {
    bundleName: 'com.oh.base_service',
    abilityName: 'ServiceAbility'
};
class j {
    constructor() {
    }
    static getInstance() {
        if (j.instance == undefined) {
            j.instance = new j();
        }
        return j.instance;
    }
    m(context, h1) {
        let i1 = context.connectServiceExtensionAbility(want, {
            onConnect(elementName, remote) {
                Log.showInfo(i, 'service connect status:onConnect');
                if (remote === null) {
                    Log.showWarn(i, 'onConnect remote is null ,connect fail');
                    return;
                }
                else {
                    let service = new BaseServiceExtProxy(remote);
                    h1(service);
                }
            },
            onDisconnect(elementName) {
                Log.showInfo(i, 'service connect status:Disconnect');
            },
            onFailed(code) {
                Log.showInfo(i, 'service connect status:onFailed ' + code);
            }
        });
        return i1;
    }
    o(context, g1) {
        if (g1 != -1) {
            context.disconnectServiceExtensionAbility(g1);
        }
    }
    processNormal(context, callback, msg, ...args) {
        let c1 = this.m(context, (service => {
            if (service == undefined) {
                callback(-10001, []);
            }
            else {
                let request = new IRequest(msg);
                request.makeParam(...args);
                service.processData(request, (errCode, f1) => {
                    callback(errCode, f1);
                    this.o(context, c1);
                });
            }
        }));
    }
    processByte(context, callback, msg, buffer) {
        let m = this.m(context, (service => {
            if (service == undefined) {
                callback(-10001, undefined);
            }
            else {
                let request = new IByteRequest(msg);
                let t = ArrayBufferUtils.arrayBuffer2Byte(buffer);
                request.setParam(t);
                service.processByte(request, (errCode, a1) => {
                    let b1 = ArrayBufferUtils.byte2ArrayBuffer(a1);
                    callback(errCode, b1);
                    this.o(context, m);
                });
            }
        }));
    }
}
export const ServiceManager = j.getInstance();
export function processNormal(context, callback, msg, ...args) {
    ServiceManager.processNormal(context, callback, msg, ...args);
}
export function processByte(context, callback, msg, buffer) {
    ServiceManager.processByte(context, callback, msg, buffer);
}
