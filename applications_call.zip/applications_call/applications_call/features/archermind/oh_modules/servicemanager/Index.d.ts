export { processNormal, processByte } from "./src/main/ets/b/ServiceManager";
