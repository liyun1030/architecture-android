import worker from '@ohos.worker'
import { Log } from '../utils/LogUtil'

const TAG = 'BaseWorkerManager'
const MAX_WORK_SIZE:number = 3
export abstract class BaseWorkerManager {
  private workingNum : number = 0
  constructor() {
    this.workingNum = 0
  }

  abstract bindWorker():worker.ThreadWorker

  abstract CallBack(msg:string,result: WorkerResultCode, data: ESObject)

  wait(msg: string, data: ESObject, buffer?: ArrayBuffer[]):Promise<void>{
    return new Promise<void>(res=>{
      setTimeout(()=>{
        this.run(msg,data,buffer)
        res()
      },3000)
    })
  }


  run(msg: string, data: ESObject, buffer?: ArrayBuffer[]) {
    if(this.workingNum == MAX_WORK_SIZE) {
      this.wait(msg,data,buffer)
      return
    }
    let worker:worker.ThreadWorker = this.bindWorker()
    this.workingNum++
    if(buffer) {
      worker.postMessage({ msg: msg, data: data }, buffer)
    } else {
      worker.postMessage({ msg: msg, data: data })
    }
    worker.onmessage = (ev => {
      this.CallBack(ev.data._key,ev.data.result, ev.data._data)
      worker.terminate()
    })
    worker.onexit = () => {
      Log.showInfo(TAG, 'exit worker')
      this.workingNum--
    }
  }
}

export enum WorkerResultCode {
  SUCCESS = 0,
  PARAM_ERR = 1,
  ERR = 2,
  MSG_NO_DEFINE = 3
}

export class workResult {
  public result: WorkerResultCode
  private _data: ESObject
  private _key: string

  constructor(key: string) {
    this._key = key
    this.result = WorkerResultCode.SUCCESS
  }

  public get key(): string {
    return this._key
  }

  public get data(): ESObject {
    return this._data
  }

  public set data(data: ESObject) {
    this._data = data
  }
}