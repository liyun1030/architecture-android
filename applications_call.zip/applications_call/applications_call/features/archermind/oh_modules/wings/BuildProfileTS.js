export const HAR_VERSION = '1.2.2';
export const BUILD_MODE_NAME = 'release';
export const DEBUG = false;
export const TARGET_NAME = 'default';
export default class BuildProfile {
}
BuildProfile.HAR_VERSION = HAR_VERSION;
BuildProfile.BUILD_MODE_NAME = BUILD_MODE_NAME;
BuildProfile.DEBUG = DEBUG;
BuildProfile.TARGET_NAME = TARGET_NAME;
