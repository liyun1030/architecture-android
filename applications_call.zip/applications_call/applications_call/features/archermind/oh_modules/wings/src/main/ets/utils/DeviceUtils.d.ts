export declare class DeviceUtils {
    static getSupportRK(): Array<string>;
    static getSupportUNISOC(): Array<string>;
    static getSupportSigmaStar(): Array<string>;
    static getAllDevice(): Array<string>;
    static getAllChip(): Array<string>;
}
