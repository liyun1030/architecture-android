import { Wings } from '../core/wings';
export declare abstract class MemberHelper {
    private static productName;
    private static chipName;
    private static _isCloseAll;
    private _ins;
    private static _isDebug;
    private _processer;
    static sbr: ESObject;
    static set isDebug(q1: boolean);
    /**
     * 关闭所有特性,跟源生一致
     * @param close :true 关闭;false 打开(默认打开)
     */
    static set closeAll(p1: boolean);
    static get closeAll(): boolean;
    static initEngine(): void;
    get Ins(): ESObject;
    set processer(o1: Wings);
    static get supportChip(): Array<string>;
    /**
     * 该方法实现类必须是boolean,返回值为true表示走订制逻辑，返回值为false表示走原始逻辑
     * @param funName
     * @param originCallBack
     * @param input
     */
    CallNoReturn(k1: string, l1: () => void, ...m1: ESObject[]): void;
    CallReturn(i1: string, ...j1: ESObject[]): ESObject | undefined;
    delay(f1: any): Promise<unknown>;
    CallNoReturnAsync(x: string, y: () => void, ...z: ESObject[]): Promise<void>;
    CallReturnAsync(q: string, ...r: ESObject[]): Promise<ESObject | undefined>;
    constructor(p: any);
    static debugObj(l: string, m: ESObject): void;
    static debugArray(e: string, f: ESObject): void;
    static debug(a: any, b: string): void;
}
