/**
 * Basic log class
 */
export declare class Log {
    static funMap: Map<string, number>;
    /**
     * Outputs info-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showInfo(y2: string, z2: string, ...a3: ESObject[]): void;
    /**
     * Outputs debug-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showDebug(v2: string, w2: string, ...x2: ESObject[]): void;
    /**
     * Outputs warning-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showWarn(s2: string, t2: string, ...u2: ESObject[]): void;
    /**
     * Outputs error-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showError(p2: string, q2: string, ...r2: ESObject[]): void;
    /**
     * Outputs fatal-level logs.
     *
     * @param tag Identifies the log tag.
     * @param format Indicates the log format string.
     * @param args Indicates the log parameters.
     * @since 7
     */
    static showFatal(m2: string, n2: string, ...o2: ESObject[]): void;
    /**
     * Checks whether logs of the specified tag, and level can be printed.
     *
     * @param tag Identifies the log tag.
     * @param level log level
     * @since 7
     */
    private static isLoggable;
    static recordStart(g2: string, h2: string): string;
    static recordEnd(b2: string, c2: string, d2: string): void;
}
