const SUPPORT_DEVICES = ["em_r18", "em_r16", "em_r18_hongzos_2_0", "HIS60A1", "pinwang_sp11_pad"];
const SUPPORT_CHIP = ['rk3399', 'rk3568', 'rk3588', 'uis7885', 'ss2381', 'ss2386'];
const RK_CHIP = ['rk3399', 'rk3568', 'rk3588'];
const UNISOC_CHIP = ['uis7885'];
const SigmaStar = ['ss2381', 'ss2386'];
export class DeviceUtils {
    static getSupportRK() {
        return RK_CHIP;
    }
    static getSupportUNISOC() {
        return UNISOC_CHIP;
    }
    static getSupportSigmaStar() {
        return SigmaStar;
    }
    static getAllDevice() {
        return SUPPORT_DEVICES;
    }
    static getAllChip() {
        return SUPPORT_CHIP;
    }
}
