/**
 * Use these variables when you tailor your ArkTS code. They must be of the const type.
 */
export declare const HAR_VERSION = "1.2.2";
export declare const BUILD_MODE_NAME = "release";
export declare const DEBUG = false;
export declare const TARGET_NAME = "default";
/**
 * BuildProfile Class is used only for compatibility purposes.
 */
export default class BuildProfile {
    static readonly HAR_VERSION = "1.2.2";
    static readonly BUILD_MODE_NAME = "release";
    static readonly DEBUG = false;
    static readonly TARGET_NAME = "default";
}
