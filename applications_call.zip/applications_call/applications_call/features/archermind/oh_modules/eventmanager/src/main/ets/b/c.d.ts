export declare function setLocalData(key: string, value: Object): void;
export declare function getLocalData(key: string, defaultValue: Object): Object;
