export declare class EventListener {
    HarcherOSonReceive: (event: string, param: ESObject) => void;
    private _events;
    constructor(o: (event: string, param: ESObject) => void, events: string[]);
    get events(): string[];
}
