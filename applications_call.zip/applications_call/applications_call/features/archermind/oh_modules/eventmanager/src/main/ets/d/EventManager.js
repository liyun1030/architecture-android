import { Log } from "../f/g";
const i = 'EventManager';
class u {
    static a1() {
        if (u.instance == undefined) {
            u.instance = new u();
        }
        return u.instance;
    }
    constructor() {
        this.b1 = new Map();
    }
    registerEventListener(listener) {
        let event = listener.events;
        event.forEach(ev => {
            Log.showInfo(i, "registerEventListener ev:" + ev);
            if (!this.b1?.has(ev)) {
                let g1 = new Array();
                g1.push(listener);
                this.b1?.set(ev, g1);
            }
            else {
                this.b1?.get(ev)?.push(listener);
            }
            Log.showInfo(i, `registerEventListener event ${ev} length:${this.b1?.get(ev)?.length}`);
        });
    }
    c1(listener) {
        let event = listener.events;
        event.forEach(ev => {
            Log.showInfo(i, "unregisterEventListener ev:" + ev);
            if (!this.b1?.has(ev)) {
            }
            else {
                let c1 = this.b1?.get(ev)?.filter((e1) => e1 != listener);
                if (c1 != undefined) {
                    this.b1?.set(ev, c1);
                }
            }
        });
    }
    publishEvent(event, param) {
        if (!this.b1?.has(event)) {
            Log.showWarn(i, `publish event:${event},param:${JSON.stringify(param)} listener not found `);
            return;
        }
        Log.showInfo(i, `publish event:${event},param:${JSON.stringify(param)} --Listener Length:` + this.b1?.get(event)?.length);
        this.b1?.get(event)?.forEach(listener => {
            listener.HarcherOSonReceive(event, param);
        });
    }
}
export const EventManager = u.a1();
export function registerEventListener(listener) {
    EventManager.registerEventListener(listener);
}
export function unRegisterEventListener(listener) {
    EventManager.c1(listener);
}
export function publishEvent(event, param) {
    EventManager.publishEvent(event, param);
}
