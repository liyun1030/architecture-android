import { EventListener } from "./e";
declare class u {
    static instance: u;
    private b1;
    static a1(): u;
    constructor();
    registerEventListener(listener: EventListener): void;
    c1(listener: EventListener): void;
    publishEvent(event: string, param: ESObject): void;
}
export declare const EventManager: u;
export declare function registerEventListener(listener: EventListener): void;
export declare function unRegisterEventListener(listener: EventListener): void;
export declare function publishEvent(event: string, param: ESObject): void;
export {};
