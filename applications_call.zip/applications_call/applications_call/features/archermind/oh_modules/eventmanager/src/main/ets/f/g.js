import hilog from '@ohos.hilog';
import { BUILD_MODE_NAME, HAR_VERSION } from "../../../../a";
const DOMAIN = 0x001f;
const i = `Wings-EventManager(${HAR_VERSION}-${BUILD_MODE_NAME})`;
const h1 = " --> ";
export class Log {
    static showInfo(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.INFO)) {
            hilog.info(DOMAIN, i, tag + h1 + format, args);
        }
    }
    static showDebug(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.DEBUG)) {
            hilog.debug(DOMAIN, i, tag + h1 + format, args);
        }
    }
    static showWarn(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.WARN)) {
            hilog.warn(DOMAIN, i, tag + h1 + format, args);
        }
    }
    static showError(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.ERROR)) {
            hilog.error(DOMAIN, i, tag + h1 + format, args);
        }
    }
    static showFatal(tag, format, ...args) {
        if (Log.isLoggable(tag, hilog.LogLevel.FATAL)) {
            hilog.fatal(DOMAIN, i, tag + h1 + format, args);
        }
    }
    static isLoggable(tag, level) {
        return hilog.isLoggable(DOMAIN, tag, level);
    }
    static recordStart(tag, k1) {
        let key = `${tag}-${k1}-${Math.floor(Math.random() * 100)}`;
        if (Log.isLoggable(tag, hilog.LogLevel.DEBUG)) {
            hilog.debug(DOMAIN, i, 'Function Follow:' + tag + '.' + k1 + '=>Function Start');
            let time = Date.now();
            Log.funMap.set(key, time);
        }
        return key;
    }
    static recordEnd(tag, i1, key) {
        let startTime;
        if (Log.isLoggable(tag, hilog.LogLevel.DEBUG)) {
            if (Log.funMap.has(key)) {
                startTime = Log.funMap.get(key);
            }
            else {
                hilog.debug(DOMAIN, i, 'Function Follow:' + tag + '.' + i1 + '=>Function End (not record Start)');
                return;
            }
            let j1 = Date.now();
            hilog.debug(DOMAIN, i, 'Function Follow:' + tag + '.' + i1 + `=>Function End (${j1 - startTime}ms)`);
            Log.funMap.delete(key);
        }
    }
}
Log.funMap = new Map();
