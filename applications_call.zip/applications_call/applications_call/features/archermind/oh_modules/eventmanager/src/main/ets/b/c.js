import { EventManager } from "../d/EventManager";
import { Log } from "../f/g";
const i = 'GlobalCache';
class j {
    constructor() {
        this.o = new Map();
        this.o.clear();
    }
    static getInstance() {
        if (j.t == undefined) {
            j.t = new j();
        }
        return j.t;
    }
    setOrCreate(key, value) {
        Log.showInfo(i, 'setOrCreate key:' + key + ",value:" + JSON.stringify(value));
        this.o.set(key, value);
        EventManager.publishEvent(key, value);
    }
    getValue(key, defaultValue) {
        if (this.o.has(key)) {
            Log.showInfo(i, 'getValue key:' + key + ",value:" + JSON.stringify(this.o.get(key)));
            return this.o.get(key);
        }
        else {
            Log.showInfo(i, 'getValue key:' + key + ",value:" + JSON.stringify(defaultValue));
            return defaultValue;
        }
    }
}
const m = j.getInstance();
export function setLocalData(key, value) {
    m.setOrCreate(key, value);
}
export function getLocalData(key, defaultValue) {
    return m.getValue(key, defaultValue);
}
