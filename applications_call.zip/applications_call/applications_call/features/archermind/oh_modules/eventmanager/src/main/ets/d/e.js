export class EventListener {
    constructor(o, events) {
        this.HarcherOSonReceive = o;
        this._events = events;
    }
    get events() {
        return this._events;
    }
}
