/**
 * Copyright (c) 2025 Archermind Technology(Nanjing) CO., LTD.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the “Software”), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

import { Log, MemberHelper } from 'wings'

const IMPORT_TAG = 'HarcherOS_import'

export class HarcherOS extends MemberHelper {
  constructor(ins: ESObject) {
    super(ins)
  }

  public init(instanceName: string): HarcherOS {
    // 这里要在程序里写好import的值,这里需要提前找好对应关系,否则会出现问题
    let tag = Log.recordStart(IMPORT_TAG, instanceName)
    switch (instanceName) {
      case 'Index':
        import('./IndexWings').then(res => {
          this.processer = new res.IndexWings(this.Ins)
          Log.recordEnd(IMPORT_TAG, instanceName, tag)
        })
        break;
    }
    return this
  }
  // 这里还可以加一些共功能的屏幕尺寸开关，如小屏幕，中屏幕，大屏幕，超大屏幕等开关，用来区分源生层因为不同的屏幕尺寸，显示的布局大小,此处方法申明为static
  public static smallScreen(): boolean {
    return false
  }

  public static nornalScreen(): boolean {
    // 这里通过屏幕长款以及dpi大小来判断
    return false
  }

  public static largeScreen(): boolean {
    // 这里通过屏幕长款以及dpi大小来判断
    return false
  }

  public static hugeScreen(): boolean {
    // 这里通过屏幕长款以及dpi大小来判断
    return false
  }
}

HarcherOS.isDebug = true
// 关闭所有特性
HarcherOS.closeAll = false

export const closeAll = HarcherOS.closeAll